package pt.exercito.rd.easywebmail.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import pt.exercito.rd.easywebmail.portal.PortalLink
import pt.exercito.rd.easywebmail.portal.PortalWebSupport

/**
 * Navegador visível onde se abre a aplicação escolhida (ex.: Webmail). Usa a sessão iniciada
 * pelo motor de login (os cookies são partilhados entre as WebViews da app).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppBrowserScreen(
    link: PortalLink,
    onClose: () -> Unit,
    onSessionExpired: () -> Unit
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableStateOf(0) }

    BackHandler(enabled = true) {
        val wv = webViewRef
        if (wv != null && wv.canGoBack()) wv.goBack() else onClose()
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Pal.bgBottom)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
            }
            Text(
                text = link.title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { webViewRef?.reload() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Recarregar", tint = Color.White)
            }
            IconButton(onClick = {
                val current = webViewRef?.url
                if (current != null) {
                    Toast.makeText(
                        context,
                        "O browser vai pedir novo login: a sessão não passa da app para o browser.",
                        Toast.LENGTH_LONG
                    ).show()
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(current)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                        Toast.makeText(context, "Não foi encontrado nenhum browser", Toast.LENGTH_SHORT).show()
                    }
                }
            }) {
                Icon(Icons.Default.OpenInBrowser, contentDescription = "Abrir no browser", tint = Color.White)
            }
        }

        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = Pal.gold
            )
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    PortalWebSupport.configure(this, interactive = true)

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            DebugLog.add("APP PAGE START " + DebugLog.safeUrl(url))
                            if (url != null && url.contains("/Login/Login")) {
                                onSessionExpired()
                            }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            DebugLog.add("APP PAGE FINISH " + DebugLog.safeUrl(url))
                        }

                        override fun onReceivedSslError(
                            view: WebView?,
                            handler: SslErrorHandler?,
                            error: SslError?
                        ) {
                            PortalWebSupport.handleSslError(ctx, handler, error)
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val uri = request?.url ?: return false
                            val scheme = uri.scheme ?: return false
                            if (scheme == "http" || scheme == "https") return false
                            try {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) {
                                // sem aplicação para este tipo de ligação
                            }
                            return true
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }
                    }

                    webViewRef = this
                    loadUrl(link.url)
                }
            }
        )
    }
}
