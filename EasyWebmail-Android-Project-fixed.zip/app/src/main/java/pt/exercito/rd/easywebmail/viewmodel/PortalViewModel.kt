package pt.exercito.rd.easywebmail.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado da escuta do SMS. O login em si está no PortalEngine.
 *
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
class PortalViewModel : ViewModel() {

    private val _smsStatus = MutableStateFlow("")
    val smsStatus: StateFlow<String> = _smsStatus.asStateFlow()

    private val _lastReceivedOtp = MutableStateFlow<String?>(null)
    val lastReceivedOtp: StateFlow<String?> = _lastReceivedOtp.asStateFlow()

    fun updateSmsStatus(status: String) {
        _smsStatus.value = status
    }

    fun onOtpReceived(otp: String) {
        _lastReceivedOtp.value = otp
        _smsStatus.value = "Código recebido."
    }

    fun clearOtp() {
        _lastReceivedOtp.value = null
    }
}
