package pt.exercito.rd.easywebmail.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/** Procura a Activity por baixo dos ContextWrapper do Compose. */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
