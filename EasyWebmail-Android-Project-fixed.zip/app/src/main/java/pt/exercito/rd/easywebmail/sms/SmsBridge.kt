package pt.exercito.rd.easywebmail.sms

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import pt.exercito.rd.easywebmail.MainActivity
import pt.exercito.rd.easywebmail.R

/**
 * Ponte entre o recetor da SMS User Consent API e a interface.
 *
 * Com o portal aberto no browser, a app está em segundo plano e o Android não deixa uma app
 * abrir a janela de consentimento da Google a partir daí. Por isso, quando o SMS chega:
 *  - se a app estiver à frente, abre-se logo a janela de consentimento;
 *  - caso contrário, mostra-se uma notificação; ao tocar, a app abre e pede o consentimento.
 */
object SmsBridge {

    const val EXTRA_CONSENT_INTENT = "pt.exercito.rd.easywebmail.CONSENT_INTENT"
    private const val CHANNEL_ID = "sms_code"
    const val NOTIFICATION_ID = 4101

    /** Definido pela MainActivity enquanto está visível. */
    @Volatile
    var foregroundHandler: ((Intent) -> Unit)? = null

    /** Para atualizar o texto de estado (ex.: tempo limite). */
    @Volatile
    var statusHandler: ((String) -> Unit)? = null

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Código SMS do portal",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Avisa quando chega o SMS com o código de verificação do portal."
        }
        manager.createNotificationChannel(channel)
    }

    fun cancelNotification(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    fun notifyConsentAvailable(context: Context, consentIntent: Intent) {
        ensureChannel(context)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return // sem permissão para mostrar notificações
        }

        val openApp = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_CONSENT_INTENT, consentIntent)
        }
        val pending = PendingIntent.getActivity(
            context,
            0,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Código SMS recebido")
            .setContentText("Toque para autorizar a leitura e copiar o código.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            // sem permissão de notificações; nada a fazer
        }
    }
}
