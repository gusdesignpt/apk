package pt.exercito.rd.easywebmail.viewmodel

import android.view.View
import android.webkit.WebView
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ViewModel para gerir o estado de navegação, status de SMS e injeção do OTP na WebView.
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
class WebViewModel : ViewModel() {

    companion object {
        const val PORTAL_LOGIN_URL = "https://portal.rd.exercito.pt/Login/Login"
    }

    private val _currentUrl = MutableStateFlow(PORTAL_LOGIN_URL)
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _pageTitle = MutableStateFlow("Portal RD - Exército Português")
    val pageTitle: StateFlow<String> = _pageTitle.asStateFlow()

    private val _smsStatus = MutableStateFlow("A escutar SMS de verificação (Google Play Services)...")
    val smsStatus: StateFlow<String> = _smsStatus.asStateFlow()

    private val _lastReceivedOtp = MutableStateFlow<String?>(null)
    val lastReceivedOtp: StateFlow<String?> = _lastReceivedOtp.asStateFlow()

    private val _injectionLog = MutableStateFlow<String?>(null)
    val injectionLog: StateFlow<String?> = _injectionLog.asStateFlow()

    // Referência em memória para a WebView atual
    private var webViewRef: WebView? = null

    fun attachWebView(webView: WebView) {
        this.webViewRef = webView
    }

    fun detachWebView() {
        this.webViewRef = null
    }

    fun setLoading(loading: Boolean) {
        _isLoading.value = loading
    }

    fun setPageTitle(title: String) {
        _pageTitle.value = title
    }

    fun setCurrentUrl(url: String) {
        _currentUrl.value = url
    }

    fun updateSmsStatus(status: String) {
        _smsStatus.value = status
    }

    /**
     * Chamado quando a SMS User Consent API devolve o código de 6 dígitos.
     */
    fun onOtpReceived(otp: String) {
        _lastReceivedOtp.value = otp
        _smsStatus.value = "Código recebido: $otp! A injetar via JavaScript..."
        injectOtpIntoWebView(otp)
    }

    /**
     * Injeta o código OTP de 6 dígitos no campo apropriado dentro da WebView
     * através de evaluateJavascript.
     */
    fun injectOtpIntoWebView(otp: String) {
        val webView = webViewRef ?: run {
            _injectionLog.value = "WebView não disponível no momento para injeção."
            return
        }

        // Script JavaScript que identifica e preenche o campo de código 2FA/SMS no Portal RD
        val jsScript = """
            (function() {
                var code = '$otp';
                console.log('[EasyWebmail] A tentar injetar código OTP:', code);

                // Seletores comuns para o campo de segundo fator / OTP do Portal RD
                var selectors = [
                    'input[name*="code" i]',
                    'input[name*="otp" i]',
                    'input[name*="token" i]',
                    'input[name*="sms" i]',
                    'input[id*="code" i]',
                    'input[id*="otp" i]',
                    'input[id*="token" i]',
                    'input[id*="sms" i]',
                    'input[autocomplete="one-time-code"]',
                    'input[type="tel"][maxlength="6"]',
                    'input[type="number"][maxlength="6"]',
                    'input[placeholder*="código" i]',
                    'input[placeholder*="SMS" i]',
                    'input[placeholder*="verificação" i]'
                ];

                var targetInput = null;

                for (var i = 0; i < selectors.length; i++) {
                    var el = document.querySelector(selectors[i]);
                    if (el && el.offsetParent !== null && !el.disabled) {
                        targetInput = el;
                        break;
                    }
                }

                // Fallback: procura o primeiro input numérico visível com tamanho apropriado
                if (!targetInput) {
                    var allInputs = document.querySelectorAll('input:not([type="hidden"]):not([type="password"]):not([type="submit"]):not([type="button"])');
                    for (var j = 0; j < allInputs.length; j++) {
                        var inp = allInputs[j];
                        var nameOrId = (inp.name || '' + inp.id || '' + inp.placeholder || '').toLowerCase();
                        if (nameOrId.indexOf('otp') !== -1 || nameOrId.indexOf('cod') !== -1 || nameOrId.indexOf('sms') !== -1 || nameOrId.indexOf('segur') !== -1) {
                            targetInput = inp;
                            break;
                        }
                    }
                }

                if (targetInput) {
                    targetInput.focus();
                    targetInput.value = code;
                    targetInput.dispatchEvent(new Event('input', { bubbles: true }));
                    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                    targetInput.style.backgroundColor = '#E8F5E9';
                    targetInput.style.borderColor = '#2E7D32';
                    targetInput.style.borderWidth = '2px';
                    return 'SUCESSO: Código ' + code + ' injetado com sucesso no campo ' + (targetInput.name || targetInput.id || '2FA');
                } else {
                    return 'AVISO: Não foi encontrado campo de OTP visível. Certifique-se de que está no ecrã de 2FA do Portal RD.';
                }
            })();
        """.trimIndent()

        webView.post {
            webView.evaluateJavascript(jsScript) { result ->
                _injectionLog.value = "Resultado JS: $result"
                _smsStatus.value = "Código $otp injetado com sucesso no formulário."
            }
        }
    }

    fun reloadPortal() {
        webViewRef?.reload()
    }

    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    fun setCanGoBack(value: Boolean) {
        _canGoBack.value = value
    }

    /** Recua uma página na WebView. Devolve true se recuou, false se não havia histórico. */
    fun goBack(): Boolean {
        val wv = webViewRef ?: return false
        return if (wv.canGoBack()) {
            wv.goBack()
            true
        } else {
            false
        }
    }

    private var softwareRendering = false

    /** Alterna entre renderização por GPU (normal) e por software. Devolve o novo estado (true = software). */
    fun toggleSoftwareRendering(): Boolean {
        val wv = webViewRef ?: return softwareRendering
        softwareRendering = !softwareRendering
        wv.setLayerType(if (softwareRendering) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_NONE, null)
        wv.invalidate()
        return softwareRendering
    }
}
