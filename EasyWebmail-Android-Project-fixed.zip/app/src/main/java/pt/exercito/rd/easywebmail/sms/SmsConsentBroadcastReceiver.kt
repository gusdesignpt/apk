package pt.exercito.rd.easywebmail.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status

/**
 * Receptor de Broadcast da SMS User Consent API (Google Play Services), declarado no manifesto.
 * Não requer as permissões READ_SMS nem RECEIVE_SMS: o utilizador autoriza cada leitura.
 *
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
class SmsConsentBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (SmsRetriever.SMS_RETRIEVED_ACTION != intent.action) return
        val extras = intent.extras ?: return

        @Suppress("DEPRECATION")
        val status: Status? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            extras.getParcelable(SmsRetriever.EXTRA_STATUS, Status::class.java)
        } else {
            extras.getParcelable(SmsRetriever.EXTRA_STATUS)
        }

        when (status?.statusCode) {
            CommonStatusCodes.SUCCESS -> {
                @Suppress("DEPRECATION")
                val consentIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT, Intent::class.java)
                } else {
                    extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT)
                }

                if (consentIntent == null) {
                    Log.w("SmsConsentReceiver", "EXTRA_CONSENT_INTENT nulo")
                    return
                }
                val foreground = SmsBridge.foregroundHandler
                if (foreground != null) {
                    foreground(consentIntent)
                } else {
                    SmsBridge.notifyConsentAvailable(context, consentIntent)
                }
            }
            CommonStatusCodes.TIMEOUT -> {
                SmsBridge.statusHandler?.invoke("Tempo limite de 5 minutos excedido. Toque no botão para tentar de novo.")
            }
            else -> {
                if (status != null) {
                    SmsBridge.statusHandler?.invoke("Erro na escuta de SMS: " + status.statusMessage)
                }
            }
        }
    }
}
