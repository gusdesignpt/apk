package pt.exercito.rd.easywebmail.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

enum class Screen(val title: String) {
    WEBVIEW("Portal RD"),
    ABOUT("Sobre a App")
}

/**
 * Estrutura principal da app em Jetpack Compose.
 * 
 * Inclui:
 * 1. TopAppBar com indicação segura e ações
 * 2. Ecrã principal com WebView do Portal do Exército
 * 3. Ecrã "Sobre a app" com explicação detalhada
 * 4. Rodapé fixo obrigatório: "Desenvolvido por SCh Cav Agostinho Fernandes 2026"
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyWebmailApp(
    viewModel: WebViewModel,
    onRequestRestartSmsListener: () -> Unit
) {
    var currentScreen by remember { mutableStateOf(Screen.WEBVIEW) }
    val smsStatus by viewModel.smsStatus.collectAsState()
    val lastOtp by viewModel.lastReceivedOtp.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "EasyWebmail",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Seguro",
                                tint = Color(0xFFC5A059),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = if (currentScreen == Screen.WEBVIEW) "portal.rd.exercito.pt" else "Informações do Sistema",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE2E8F0)
                            )
                        )
                    }
                },
                actions = {
                    if (currentScreen == Screen.WEBVIEW) {
                        IconButton(onClick = { viewModel.reloadPortal() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Recarregar Portal",
                                tint = Color.White
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            currentScreen = if (currentScreen == Screen.WEBVIEW) Screen.ABOUT else Screen.WEBVIEW
                        }
                    ) {
                        Icon(
                            imageVector = if (currentScreen == Screen.WEBVIEW) Icons.Default.Info else Icons.Default.Web,
                            contentDescription = if (currentScreen == Screen.WEBVIEW) "Sobre a App" else "Voltar ao Portal",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B382B) // Verde Exército Português
                )
            )
        },
        bottomBar = {
            // Rodapé obrigatório em letras pequenas
            Surface(
                color = Color(0xFF0F172A),
                contentColor = Color(0xFF94A3B8),
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Desenvolvido por SCh Cav Agostinho Fernandes 2026",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFCBD5E1),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentScreen) {
                Screen.WEBVIEW -> {
                    WebViewScreen(
                        viewModel = viewModel,
                        onRequestRestartSms = onRequestRestartSmsListener,
                        onNavigateToAbout = { currentScreen = Screen.ABOUT }
                    )
                }
                Screen.ABOUT -> {
                    AboutScreen(
                        onNavigateBack = { currentScreen = Screen.WEBVIEW }
                    )
                }
            }
        }
    }
}
