package pt.exercito.rd.easywebmail.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

enum class Screen(val title: String) {
    ASSISTANT("Assistente"),
    ABOUT("Sobre a App")
}

/**
 * Estrutura principal da app: assistente do código SMS (o portal abre no browser)
 * e ecrã "Sobre a app". Rodapé fixo: "Desenvolvido por SCh Cav Agostinho Fernandes 2026".
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyWebmailApp(
    viewModel: WebViewModel,
    onStartListening: () -> Unit
) {
    var currentScreen by remember { mutableStateOf(Screen.ASSISTANT) }

    BackHandler(enabled = currentScreen == Screen.ABOUT) {
        currentScreen = Screen.ASSISTANT
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "EasyWebmail",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Seguro",
                                tint = Color(0xFFC5A059),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = if (currentScreen == Screen.ASSISTANT) "Assistente de código SMS" else "Informações do Sistema",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE2E8F0)
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            currentScreen = if (currentScreen == Screen.ASSISTANT) Screen.ABOUT else Screen.ASSISTANT
                        }
                    ) {
                        Icon(
                            imageVector = if (currentScreen == Screen.ASSISTANT) Icons.Default.Info else Icons.Default.Sms,
                            contentDescription = if (currentScreen == Screen.ASSISTANT) "Sobre a App" else "Voltar ao assistente",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B382B) // Verde Exército Português
                )
            )
        },
        bottomBar = {
            Surface(
                color = Color(0xFF0F172A),
                contentColor = Color(0xFF94A3B8),
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Desenvolvido por SCh Cav Agostinho Fernandes 2026",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFCBD5E1),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentScreen) {
                Screen.ASSISTANT -> AssistantScreen(
                    viewModel = viewModel,
                    onStartListening = onStartListening
                )
                Screen.ABOUT -> AboutScreen(
                    onNavigateBack = { currentScreen = Screen.ASSISTANT }
                )
            }
        }
    }
}
