package pt.exercito.rd.easywebmail.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.portal.PortalEngine
import pt.exercito.rd.easywebmail.portal.PortalStage
import pt.exercito.rd.easywebmail.viewmodel.PortalViewModel

/**
 * Estrutura principal: login nativo, código SMS nativo, lista de aplicações (que abrem no browser).
 * Rodapé fixo: "Desenvolvido por SCh Cav Agostinho Fernandes 2026".
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EasyWebmailApp(
    viewModel: PortalViewModel,
    onStartListening: () -> Unit
) {
    val context = LocalContext.current
    val stage by PortalEngine.stage.collectAsState()
    var showAbout by remember { mutableStateOf(false) }

    // Depois de um login bem sucedido, memoriza as credenciais se o utilizador o pediu.
    LaunchedEffect(stage) {
        if (stage == PortalStage.LOGGED_IN) {
            PortalEngine.takePendingSave()?.let { credentials ->
                saveCredentialsWithFingerprint(context, credentials.first, credentials.second)
            }
        }
    }

    BackHandler(enabled = showAbout) {
        showAbout = false
    }

    val subtitle = when {
        showAbout -> "Informações do Sistema"
        stage == PortalStage.LOGGED_IN -> "Aplicações"
        stage == PortalStage.WAITING_SMS || stage == PortalStage.SUBMITTING_CODE -> "Código de segurança"
        else -> "Autenticação"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "EasyWebmail",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Seguro",
                                tint = Color(0xFFC5A059),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE2E8F0)
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        modifier = Modifier.size(40.dp),
                        onClick = { showAbout = !showAbout }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Sobre a App",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B382B) // Verde Exército Português
                )
            )
        },
        bottomBar = {
            Surface(
                color = Color(0xFF0F172A),
                contentColor = Color(0xFF94A3B8),
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Desenvolvido por SCh Cav Agostinho Fernandes 2026",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFCBD5E1),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                showAbout -> AboutScreen(
                    onNavigateBack = { showAbout = false },
                    onSaveLog = {
                        val saved = DebugLog.saveToDownloads(context)
                        Toast.makeText(
                            context,
                            if (saved != null) "Registo guardado: $saved" else "Não foi possível guardar o registo",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                )
                stage == PortalStage.LOGGED_IN -> PortalHomeScreen(
                    onOpenLink = { link -> openInBrowser(context, link.url) },
                    onOpenPortalPage = { openInBrowser(context, PortalEngine.MAIN_URL) },
                    onLogout = { PortalEngine.logout() }
                )
                stage == PortalStage.WAITING_SMS || stage == PortalStage.SUBMITTING_CODE ->
                    SmsCodeScreen(viewModel = viewModel)
                else -> LoginScreen(
                    viewModel = viewModel,
                    onStartListening = onStartListening
                )
            }
        }
    }
}

/** Abre o endereço no browser do telemóvel (fora da app). */
private fun openInBrowser(context: android.content.Context, url: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Não foi encontrado nenhum browser", Toast.LENGTH_SHORT).show()
    }
}
