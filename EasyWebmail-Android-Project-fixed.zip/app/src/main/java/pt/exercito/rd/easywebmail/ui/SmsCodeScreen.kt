package pt.exercito.rd.easywebmail.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.portal.PortalEngine
import pt.exercito.rd.easywebmail.portal.PortalStage
import pt.exercito.rd.easywebmail.viewmodel.PortalViewModel

/** Ecrã nativo do código de segurança (SMS). Preenche e submete sozinho quando o SMS é autorizado. */
@Composable
fun SmsCodeScreen(viewModel: PortalViewModel) {
    val stage by PortalEngine.stage.collectAsState()
    val engineError by PortalEngine.errorMessage.collectAsState()
    val prompt by PortalEngine.smsPrompt.collectAsState()
    val userLabel by PortalEngine.userLabel.collectAsState()
    val smsStatus by viewModel.smsStatus.collectAsState()
    val otp by viewModel.lastReceivedOtp.collectAsState()

    var code by remember { mutableStateOf("") }
    var autoSubmitted by remember { mutableStateOf<String?>(null) }
    val busy = stage == PortalStage.SUBMITTING_CODE

    // Quando o SMS é autorizado, preenche o campo e submete uma única vez.
    LaunchedEffect(otp, stage) {
        val received = otp
        if (received != null && received != autoSubmitted && stage == PortalStage.WAITING_SMS) {
            code = received
            autoSubmitted = received
            PortalEngine.submitCode(received)
        }
    }

    val phoneEnding = Regex("X+(\\d{3,4})").find(prompt)?.groupValues?.get(1)
    val explanation = if (phoneEnding != null) {
        "Foi enviado um SMS para o telemóvel terminado em $phoneEnding. Introduza o código de segurança."
    } else if (prompt.isNotBlank()) {
        prompt
    } else {
        "Foi enviado um SMS para o seu telemóvel. Introduza o código de segurança."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Pal.bgTop, Pal.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(Pal.card)
                    .border(1.dp, Pal.cardBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Sms,
                    contentDescription = null,
                    tint = Pal.gold,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Código de segurança",
                color = Pal.textMain,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            if (userLabel.isNotBlank()) {
                Text(
                    text = userLabel,
                    color = Pal.gold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(24.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Pal.card)
                    .border(1.dp, Pal.cardBorder, RoundedCornerShape(20.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(text = explanation, color = Pal.textMain, fontSize = 14.sp)

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.filter { ch -> ch.isLetterOrDigit() }.take(10) },
                    label = { Text("Código") },
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 28.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = portalFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                if (engineError != null) {
                    Text(text = engineError ?: "", color = Pal.error, fontSize = 14.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (busy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Pal.gold,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("A validar o código…", color = Pal.textSoft, fontSize = 12.sp)
                    } else if (otp == null) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Pal.gold,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = if (smsStatus.isNotBlank()) smsStatus else "À espera do SMS…",
                            color = Pal.textSoft,
                            fontSize = 12.sp
                        )
                    } else {
                        Text("Código recebido.", color = Pal.gold, fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = { PortalEngine.submitCode(code) },
                    enabled = code.isNotBlank() && !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Pal.green,
                        contentColor = Color.White
                    )
                ) {
                    Text("Submeter", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                OutlinedButton(
                    onClick = { PortalEngine.reset() },
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Cancelar", color = Pal.textMain)
                }
            }
        }
    }
}
