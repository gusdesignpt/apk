package pt.exercito.rd.easywebmail.portal

import android.content.Context
import android.net.http.SslError
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import pt.exercito.rd.easywebmail.ui.DebugLog

data class PortalLink(val title: String, val url: String)

enum class PortalStage {
    IDLE,
    LOADING_LOGIN,
    LOGIN_READY,
    SUBMITTING_CREDENTIALS,
    WAITING_SMS,
    SUBMITTING_CODE,
    LOGGED_IN
}

/**
 * Motor do login: uma WebView escondida que fala com o portal verdadeiro (a cifra da password e os
 * formulários são do próprio portal). A app mostra ecrãs nativos e o motor preenche e submete as
 * páginas por JavaScript.
 *
 * A sessão fica nos cookies da app, partilhados com a WebView visível onde se abrem as aplicações.
 *
 * Todas as funções devem ser chamadas na thread principal.
 */
object PortalEngine {

    const val LOGIN_URL = "https://portal.rd.exercito.pt/Login/Login"
    const val MAIN_URL = "https://portal.rd.exercito.pt/Portal/Main"

    private val _stage = MutableStateFlow(PortalStage.IDLE)
    val stage: StateFlow<PortalStage> = _stage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _smsPrompt = MutableStateFlow("")
    val smsPrompt: StateFlow<String> = _smsPrompt.asStateFlow()

    private val _userLabel = MutableStateFlow("")
    val userLabel: StateFlow<String> = _userLabel.asStateFlow()

    private val _links = MutableStateFlow<List<PortalLink>>(emptyList())
    val links: StateFlow<List<PortalLink>> = _links.asStateFlow()

    private var appContext: Context? = null
    private var webView: WebView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var pendingNim: String? = null
    private var pendingPassword: String? = null
    private var pendingSave: Pair<String, String>? = null

    fun init(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    // ---------------------------------------------------------------- WebView escondida

    private fun engine(): WebView {
        webView?.let { return it }
        val ctx = appContext ?: throw IllegalStateException("PortalEngine.init() não foi chamado")
        val wv = WebView(ctx)
        PortalWebSupport.configure(wv, interactive = false)
        wv.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == null) return
                DebugLog.add("MOTOR PAGE FINISH " + DebugLog.safeUrl(url))
                handlePageFinished(url)
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                val ok = PortalWebSupport.handleSslError(ctx, handler, error)
                if (!ok) {
                    fail("Não foi possível validar o certificado do portal.")
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    DebugLog.add("MOTOR ERRO REDE " + (error?.errorCode ?: 0) + " " + (error?.description ?: "?"))
                    fail("Não foi possível ligar ao portal. Verifique a ligação à internet.")
                }
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                DebugLog.add("MOTOR: processo de renderização terminou")
                view?.destroy()
                webView = null
                fail("O motor interno foi reiniciado. Tente novamente.")
                return true
            }
        }
        webView = wv
        return wv
    }

    private fun fail(message: String) {
        _errorMessage.value = message
        pendingPassword = null
        pendingSave = null
        _stage.value = PortalStage.IDLE
    }

    private fun runJs(script: String, callback: (String?) -> Unit) {
        engine().evaluateJavascript(script) { raw ->
            val text = if (raw == null || raw == "null") {
                null
            } else {
                try {
                    JSONArray("[$raw]").optString(0)
                } catch (e: Exception) {
                    raw
                }
            }
            callback(text)
        }
    }

    // ---------------------------------------------------------------- API usada pelos ecrãs

    /** Carrega a página de login em segundo plano, para a submissão ser imediata. */
    fun prepare() {
        if (_stage.value != PortalStage.IDLE) return
        _errorMessage.value = null
        _stage.value = PortalStage.LOADING_LOGIN
        clearSession()
        engine().loadUrl(LOGIN_URL)
    }

    fun login(nim: String, password: String, remember: Boolean) {
        _errorMessage.value = null
        pendingNim = nim.trim()
        pendingPassword = password
        pendingSave = if (remember) Pair(nim.trim(), password) else null
        when (_stage.value) {
            PortalStage.LOGIN_READY -> submitPendingCredentials()
            PortalStage.LOADING_LOGIN -> { /* submete quando a página estiver pronta */ }
            PortalStage.IDLE -> prepare()
            else -> { /* já em curso */ }
        }
    }

    fun submitCode(code: String) {
        if (_stage.value != PortalStage.WAITING_SMS) return
        _errorMessage.value = null
        _stage.value = PortalStage.SUBMITTING_CODE
        runJs(codeScript(code)) { result ->
            if (result != "ok") {
                DebugLog.add("MOTOR: falha ao submeter o código ($result)")
                _errorMessage.value = "Não foi possível submeter o código ao portal."
                _stage.value = PortalStage.WAITING_SMS
            }
        }
    }

    /** Termina a sessão no portal e volta ao login. */
    fun logout() {
        if (_stage.value == PortalStage.LOGGED_IN) {
            webView?.evaluateJavascript(
                "fetch('/Portal/SignOut',{method:'POST',credentials:'include'});",
                null
            )
        }
        mainHandler.postDelayed({ reset() }, 700)
    }

    /** Apaga a sessão e volta ao estado inicial. */
    fun reset() {
        pendingNim = null
        pendingPassword = null
        pendingSave = null
        _errorMessage.value = null
        _smsPrompt.value = ""
        _userLabel.value = ""
        _links.value = emptyList()
        clearSession()
        webView?.let {
            it.stopLoading()
            it.loadUrl("about:blank")
            it.clearHistory()
        }
        _stage.value = PortalStage.IDLE
    }

    /** Credenciais a memorizar depois de um login bem sucedido (entrega uma única vez). */
    fun takePendingSave(): Pair<String, String>? {
        val value = pendingSave
        pendingSave = null
        return value
    }

    // ---------------------------------------------------------------- lógica das páginas

    private fun clearSession() {
        val cookies = CookieManager.getInstance()
        cookies.removeAllCookies(null)
        cookies.flush()
    }

    private fun handlePageFinished(url: String) {
        when {
            url.contains("/Login/MultiChallenge") -> onMultiChallengePage()
            url.contains("/Portal/Main") -> onMainPage()
            url.contains("/Login/Login") -> onLoginPage()
        }
    }

    private fun onLoginPage() {
        when (_stage.value) {
            PortalStage.LOADING_LOGIN -> {
                _stage.value = PortalStage.LOGIN_READY
                if (pendingNim != null && pendingPassword != null) submitPendingCredentials()
            }
            PortalStage.SUBMITTING_CREDENTIALS -> {
                // a página de login voltou: as credenciais foram recusadas
                runJs(ERROR_TEXT_SCRIPT) { text ->
                    _errorMessage.value =
                        if (text.isNullOrBlank()) "NIM ou password inválidos." else text
                    pendingPassword = null
                    pendingSave = null
                    _stage.value = PortalStage.LOGIN_READY
                }
            }
            PortalStage.WAITING_SMS, PortalStage.SUBMITTING_CODE -> {
                reset()
                _errorMessage.value = "A sessão expirou. Volte a entrar."
            }
            else -> { /* nada a fazer */ }
        }
    }

    private fun onMultiChallengePage() {
        when (_stage.value) {
            PortalStage.SUBMITTING_CREDENTIALS -> {
                pendingPassword = null
                runJs(PROMPT_TEXT_SCRIPT) { text ->
                    val lines = (text ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                    val first = lines.firstOrNull() ?: ""
                    if (Regex("\\(\\d+\\)").containsMatchIn(first)) {
                        _userLabel.value = first.trimEnd(',', ' ')
                        _smsPrompt.value = lines.drop(1).joinToString("\n")
                    } else {
                        _userLabel.value = ""
                        _smsPrompt.value = lines.joinToString("\n")
                    }
                    _stage.value = PortalStage.WAITING_SMS
                }
            }
            PortalStage.SUBMITTING_CODE -> {
                // a página do código voltou: o código foi recusado
                runJs(ERROR_TEXT_SCRIPT) { text ->
                    _errorMessage.value =
                        if (text.isNullOrBlank()) "Código inválido ou expirado." else text
                    _stage.value = PortalStage.WAITING_SMS
                }
            }
            else -> { /* nada a fazer */ }
        }
    }

    private fun onMainPage() {
        val stage = _stage.value
        if (stage == PortalStage.LOGGED_IN || stage == PortalStage.IDLE) return
        runJs(LINKS_SCRIPT) { text ->
            try {
                val obj = JSONObject(text ?: "{}")
                val user = obj.optString("user", "")
                if (user.isNotBlank()) _userLabel.value = user
                val array = obj.optJSONArray("links")
                val result = ArrayList<PortalLink>()
                if (array != null) {
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        result.add(PortalLink(item.getString("title"), item.getString("url")))
                    }
                }
                _links.value = result
                DebugLog.add("MOTOR: " + result.size + " aplicações lidas do portal")
            } catch (e: Exception) {
                DebugLog.add("MOTOR: erro a ler as aplicações: " + e.message)
            }
            _errorMessage.value = null
            _stage.value = PortalStage.LOGGED_IN
        }
    }

    private fun submitPendingCredentials() {
        val nim = pendingNim ?: return
        val password = pendingPassword ?: return
        _stage.value = PortalStage.SUBMITTING_CREDENTIALS
        runJs(credentialsScript(nim, password)) { result ->
            if (result != "ok") {
                DebugLog.add("MOTOR: falha ao preencher o login ($result)")
                _errorMessage.value = "Não foi possível preencher o formulário do portal."
                pendingPassword = null
                pendingSave = null
                _stage.value = PortalStage.LOGIN_READY
            }
        }
    }

    // ---------------------------------------------------------------- scripts das páginas do portal

    private fun credentialsScript(nim: String, password: String): String = """
        (function(nim, pwd){
          var u = document.getElementById('userName');
          var p = document.getElementById('passwordDisplayed');
          if (!u || !p) return 'sem-campos';
          function fire(el){ ['input','change','keyup'].forEach(function(t){ el.dispatchEvent(new Event(t, {bubbles:true})); }); }
          u.value = nim; fire(u);
          p.value = pwd; fire(p);
          var b = document.getElementById('LoginButton');
          if (!b) return 'sem-botao';
          b.click();
          return 'ok';
        })(${JSONObject.quote(nim)}, ${JSONObject.quote(password)})
    """.trimIndent()

    private fun codeScript(code: String): String = """
        (function(code){
          var all = [].slice.call(document.querySelectorAll('input'));
          var fields = all.filter(function(i){
            return ['hidden','submit','button','radio','checkbox'].indexOf(i.type) < 0 && i.offsetParent !== null;
          });
          if (!fields.length) return 'sem-campo';
          var f = fields[0];
          f.value = code;
          ['input','change','keyup'].forEach(function(t){ f.dispatchEvent(new Event(t, {bubbles:true})); });
          var b = document.getElementById('LoginButton') || document.querySelector('input[type=submit]') || document.querySelector('button.button-green');
          if (b) { b.click(); return 'ok'; }
          if (f.form) { f.form.submit(); return 'ok'; }
          return 'sem-botao';
        })(${JSONObject.quote(code)})
    """.trimIndent()

    private val ERROR_TEXT_SCRIPT = """
        (function(){
          var e = document.getElementById('errorMsgDIV');
          if (!e) { e = document.querySelector('.error-msg-div, .error-msg, .error'); }
          return e ? (e.innerText || e.textContent || '').trim() : '';
        })()
    """.trimIndent()

    private val PROMPT_TEXT_SCRIPT = """
        (function(){
          var skip = ['Exército Mobile', 'Cancel', 'Submit', "I didn't get the verification code", 'Sign In', 'English', 'Português'];
          var lines = (document.body.innerText || '').split('\n').map(function(s){ return s.trim(); }).filter(function(s){
            return s.length > 0 && skip.indexOf(s) < 0 && s.indexOf('©') < 0 && s.indexOf('Copyright') < 0;
          });
          return lines.join('\n');
        })()
    """.trimIndent()

    private val LINKS_SCRIPT = """
        (function(){
          var r = {user: '', links: []};
          var u = document.querySelector('.user-name');
          if (u) r.user = (u.innerText || u.textContent || '').trim();
          var as = document.querySelectorAll('a.UrlLinks');
          for (var i = 0; i < as.length; i++) {
            var a = as[i];
            var t = a.querySelector('.url-text');
            var title = t ? (t.innerText || t.textContent || '').trim() : (a.getAttribute('title') || '').trim();
            var h = a.getAttribute('href') || '';
            var m = h.match(/openWebApp\('([^']+)'\)/);
            var url = m ? decodeURIComponent(m[1]) : '';
            if (title && url) r.links.push({title: title, url: url});
          }
          return JSON.stringify(r);
        })()
    """.trimIndent()
}
