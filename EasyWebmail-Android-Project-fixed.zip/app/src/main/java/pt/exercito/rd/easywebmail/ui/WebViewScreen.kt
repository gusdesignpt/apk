package pt.exercito.rd.easywebmail.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.http.SslError
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

/**
 * Ecrã da WebView em Jetpack Compose.
 * 
 * Carrega https://portal.rd.exercito.pt/Login/Login com todas as configurações de segurança,
 * suporte para JavaScript e ponte de injeção automática para códigos OTP recebidos via SMS User Consent.
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    viewModel: WebViewModel,
    onRequestRestartSms: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val isLoading by viewModel.isLoading.collectAsState()
    val smsStatus by viewModel.smsStatus.collectAsState()
    val lastOtp by viewModel.lastReceivedOtp.collectAsState()
    var showIntranetBanner by remember { mutableStateOf(true) }
    val hostContext = LocalContext.current

    // Botão/gesto "voltar" do Android: recua na WebView; sem histórico, sai da app.
    BackHandler(enabled = true) {
        if (viewModel.goBack()) {
            DebugLog.add("VOLTAR: recuou uma página")
        } else {
            DebugLog.add("VOLTAR: sem histórico, a sair da app")
            (hostContext as? Activity)?.finish()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Alerta informativo: Requisito de ativação de Duplo Fator na Intranet
        AnimatedVisibility(visible = showIntranetBanner) {
            Surface(
                color = Color(0xFFFEF3C7), // Âmbar suave
                contentColor = Color(0xFF92400E),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Nota de Configuração",
                        tint = Color(0xFFB45309),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Atenção: É necessário ativar a autenticação por duplo fator na Intranet em Serviços > multifator e registar email e número de telefone.",
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = { showIntranetBanner = false },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Entendido", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                    }
                }
            }
        }

        // Barra de estado de escuta de SMS
        Surface(
            color = Color(0xFF1E293B),
            contentColor = Color(0xFFE2E8F0),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (lastOtp != null) Icons.Default.CheckCircle else Icons.Default.Sms,
                    contentDescription = null,
                    tint = if (lastOtp != null) Color(0xFF4ADE80) else Color(0xFFC5A059),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = smsStatus,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 11.sp,
                    color = Color(0xFFCBD5E1),
                    modifier = Modifier.weight(1f)
                )
                if (lastOtp != null) {
                    Surface(
                        color = Color(0xFF166534),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(
                            text = "OTP: $lastOtp",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFFC5A059),
                trackColor = Color(0xFF1B382B)
            )
        }

        // Contentor da WebView Nativa
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clipToBounds()
        ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                // Diagnóstico: mostra apenas o último evento relevante (curto) na barra de estado
                var lastDiag = ""
                fun shortUrl(u: String?): String = (u ?: "").removePrefix("https://").take(60)
                fun logDiag(msg: String) {
                    if (msg == lastDiag) return
                    lastDiag = msg
                    viewModel.updateSmsStatus(msg.take(90))
                }

                WebView(context).apply {
                    setBackgroundColor(android.graphics.Color.WHITE)

                    // Configurações essenciais para o Portal RD
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        setSupportZoom(true)
                        builtInZoomControls = true
                        displayZoomControls = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        cacheMode = WebSettings.LOAD_DEFAULT
                        userAgentString = userAgentString.replace("; wv", "")
                    }
                    DebugLog.add("UA: " + settings.userAgentString)

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            DebugLog.add("PAGE START " + DebugLog.safeUrl(url))
                            // Teste: no webmail (OWA) desenha por software, para contornar páginas em branco por GPU.
                            val desiredLayer = if (url?.contains("/owa/") == true) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_NONE
                            if (view != null && view.layerType != desiredLayer) {
                                view.setLayerType(desiredLayer, null)
                                DebugLog.add("Camada de renderização: " + (if (desiredLayer == View.LAYER_TYPE_SOFTWARE) "SOFTWARE" else "normal (GPU)"))
                            }
                            viewModel.setLoading(true)
                            url?.let { viewModel.setCurrentUrl(it) }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            DebugLog.add("PAGE FINISH " + DebugLog.safeUrl(url))
                            if (url != null && url.startsWith("https://")) {
                                view?.let { wv ->
                                    // Sonda de visibilidade: não regista título nem texto da página.
                                    val probeJs = """
                                        (function(){
                                          var r={};
                                          function d(e){ if(!e) return 'null'; var s=e.tagName?e.tagName.toLowerCase():'?'; if(e.id) s+='#'+e.id; if(e.className&&typeof e.className==='string') s+='.'+e.className.split(' ').slice(0,2).join('.'); return s; }
                                          function st(e){ try{ var c=getComputedStyle(e); var b=e.getBoundingClientRect(); return d(e)+' disp='+c.display+' vis='+c.visibility+' op='+c.opacity+' bg='+c.backgroundColor+' rect='+Math.round(b.width)+'x'+Math.round(b.height); }catch(x){ return 'erro '+x; } }
                                          try{ r.href=location.origin+location.pathname; }catch(e){}
                                          r.ready=document.readyState;
                                          r.vis=document.visibilityState; r.focus=document.hasFocus();
                                          r.win=window.innerWidth+'x'+window.innerHeight; r.dpr=window.devicePixelRatio; r.screen=screen.width+'x'+screen.height;
                                          try{ r.paint=performance.getEntriesByType('paint').map(function(p){ return p.name+'@'+Math.round(p.startTime); }).join(','); }catch(e){ r.paint='erro'; }
                                          r.bodyTextLen=document.body?(document.body.innerText||'').length:-1;
                                          if(document.documentElement) r.html=st(document.documentElement);
                                          if(document.body){ r.body=st(document.body); r.children=[].slice.call(document.body.children).slice(0,10).map(st); }
                                          try{ r.center=d(document.elementFromPoint(window.innerWidth/2,window.innerHeight/2)); }catch(e){ r.center='erro'; }
                                          try{ var all=document.querySelectorAll('*'); var v=0; for(var i=0;i<all.length&&i<6000;i++){ var q=all[i]; if(q.getClientRects().length>0&&getComputedStyle(q).visibility!=='hidden') v++; } r.elems=all.length; r.visibleElems=v; }catch(e){ r.elems='erro'; }
                                          r.iframes=document.getElementsByTagName('iframe').length;
                                          return JSON.stringify(r);
                                        })()
                                    """.trimIndent()
                                    if (url.contains("/owa/")) {
                                        for (pxDelay in longArrayOf(15000L, 30000L, 45000L)) {
                                            wv.postDelayed({
                                                DebugLog.add("PIXELS +" + (pxDelay / 1000) + "s: " + describePixels(wv))
                                            }, pxDelay)
                                        }
                                    }
                                    for (delayMs in longArrayOf(3000L, 15000L, 30000L, 45000L)) {
                                        wv.postDelayed({
                                            wv.evaluateJavascript(probeJs) { r ->
                                                DebugLog.add("SONDA DOM +" + (delayMs / 1000) + "s: " + (r ?: "null"))
                                            }
                                        }, delayMs)
                                    }
                                }
                            }
                            viewModel.setLoading(false)
                            url?.let { viewModel.setCurrentUrl(it) }

                            // DIAGNÓSTICO: o formulário do portal começa oculto (display:none) e só aparece
                            // depois de o JavaScript da página correr. Mostra se ficou visível ou não.
                            viewModel.setCanGoBack(view?.canGoBack() == true)
                            if (url != null && url.contains("/Login/Login")) {
                                view?.let { wv ->
                                    wv.postDelayed({
                                        wv.evaluateJavascript(
                                            "(function(){var e=document.getElementById('loginContainerTable');" +
                                                "return e?getComputedStyle(e).display:'sem-formulario';})()"
                                        ) { r ->
                                            if (r != null && r != "null") {
                                                logDiag("Formulário de login: " + r)
                                            }
                                        }
                                    }, 1500)
                                }
                            }

                            // Se já tivermos um OTP recebido antes de a página terminar de carregar, injeta
                            if (url != null && url.contains("/Login/")) {
                                lastOtp?.let { otp ->
                                    viewModel.injectOtpIntoWebView(otp)
                                }
                            }
                        }

                        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                            viewModel.setCanGoBack(view?.canGoBack() == true)
                        }

                        private fun showErrorPage(view: WebView?, titulo: String, detalhe: String, url: String?) {
                            viewModel.setLoading(false)
                            val html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'></head>" +
                                "<body style='font-family:sans-serif;padding:20px;background:#0F241A;color:#F1F5F9'>" +
                                "<h2 style='color:#DFBF7A'>" + TextUtils.htmlEncode(titulo) + "</h2>" +
                                "<p>" + TextUtils.htmlEncode(detalhe) + "</p>" +
                                "<p style='color:#94A3B8;font-size:13px'>URL: " + TextUtils.htmlEncode(url ?: "") + "</p>" +
                                "<p style='color:#94A3B8;font-size:13px'>Toque no botão de recarregar (canto superior direito) para tentar de novo.</p>" +
                                "</body></html>"
                            view?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            DebugLog.add(
                                "ERRO REDE " + (if (request?.isForMainFrame == true) "[principal] " else "[recurso] ") +
                                    (error?.errorCode ?: 0) + " " + (error?.description ?: "?") + " " +
                                    DebugLog.safeUrl(request?.url?.toString())
                            )
                            if (request?.isForMainFrame == true) {
                                showErrorPage(
                                    view,
                                    "Não foi possível abrir o portal",
                                    "Erro " + (error?.errorCode ?: 0) + ": " + (error?.description ?: "desconhecido"),
                                    request.url?.toString()
                                )
                            } else {
                                logDiag("Falhou: " + (error?.description ?: "?") + " " + shortUrl(request?.url?.toString()))
                            }
                        }

                        override fun onReceivedSslError(
                            view: WebView?,
                            handler: SslErrorHandler?,
                            error: SslError?
                        ) {
                            // Aceita APENAS se o certificado do portal for assinado pelo intermédio da Sectigo
                            // incluído na app (o servidor não o envia). Qualquer outro erro continua bloqueado.
                            if (PortalCertificateValidator.isTrusted(context, error)) {
                                DebugLog.add("SSL aceite (intermédio Sectigo) " + DebugLog.safeUrl(error?.url))
                                handler?.proceed()
                                return
                            }
                            DebugLog.add("SSL RECUSADO código " + (error?.primaryError ?: -1) + " " + DebugLog.safeUrl(error?.url))
                            handler?.cancel()
                            val sameAsMain = error?.url?.substringBefore('#') ==
                                viewModel.currentUrl.value.substringBefore('#')
                            if (!sameAsMain) {
                                logDiag("SSL recusado: " + shortUrl(error?.url))
                                return
                            }
                            showErrorPage(
                                view,
                                "Erro de certificado SSL",
                                "O certificado do portal não é considerado de confiança por este telemóvel (código " +
                                    (error?.primaryError ?: -1) + ").",
                                error?.url
                            )
                        }

                        override fun onReceivedHttpError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            errorResponse: WebResourceResponse?
                        ) {
                            DebugLog.add(
                                "HTTP " + (errorResponse?.statusCode ?: 0) + " " +
                                    (if (request?.isForMainFrame == true) "[principal] " else "[recurso] ") +
                                    DebugLog.safeUrl(request?.url?.toString())
                            )
                            logDiag("HTTP " + (errorResponse?.statusCode ?: 0) + " " + shortUrl(request?.url?.toString()))
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            DebugLog.add("NAVEGAR " + DebugLog.safeUrl(request?.url?.toString()))
                            // Mantém a navegação restrita dentro da WebView
                            return false
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            if (consoleMessage != null) {
                                DebugLog.add(
                                    "CONSOLA " + consoleMessage.messageLevel() + ": " +
                                        consoleMessage.message().take(300) + " @" +
                                        DebugLog.safeUrl(consoleMessage.sourceId()) + ":" + consoleMessage.lineNumber()
                                )
                            }
                            // DIAGNÓSTICO: mostra o último erro de JavaScript da página na barra de estado.
                            if (consoleMessage != null &&
                                consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR &&
                                !consoleMessage.message().contains("Content Security Policy", ignoreCase = true)
                            ) {
                                logDiag(
                                    "JS: " + consoleMessage.message().take(100) +
                                        " (linha " + consoleMessage.lineNumber() + ")"
                                )
                            }
                            return false
                        }

                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            title?.let { viewModel.setPageTitle(it) }
                        }
                    }

                    viewModel.attachWebView(this)
                    loadUrl(WebViewModel.PORTAL_LOGIN_URL)
                }
            },
            update = { webView ->
                viewModel.attachWebView(webView)
            }
        )
        }
    }
}

/**
 * Desenha a WebView num bitmap (por software) e diz que percentagem de pixels NÃO é branca.
 * Serve para distinguir "a página está em branco" de "a página existe mas o ecrã não a mostra".
 * Não guarda nem regista o conteúdo da imagem, apenas a percentagem.
 */
private fun describePixels(wv: WebView): String {
    return try {
        val w = wv.width
        val h = wv.height
        if (w <= 0 || h <= 0) return "WebView sem tamanho"
        val scale = 0.25f
        val bmp = Bitmap.createBitmap(
            (w * scale).toInt().coerceAtLeast(1),
            (h * scale).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bmp)
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.scale(scale, scale)
        wv.draw(canvas)
        val pixels = IntArray(bmp.width * bmp.height)
        bmp.getPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        var nonWhite = 0
        for (p in pixels) {
            if ((p and 0x00FFFFFF) != 0x00FFFFFF) nonWhite++
        }
        bmp.recycle()
        val pct = if (pixels.isEmpty()) 0 else nonWhite * 100 / pixels.size
        "$pct% de pixels não brancos (${w}x$h, camada=${wv.layerType})"
    } catch (e: Exception) {
        "erro: " + e.message
    }
}
