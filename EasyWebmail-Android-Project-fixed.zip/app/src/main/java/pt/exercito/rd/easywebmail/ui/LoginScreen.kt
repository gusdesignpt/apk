package pt.exercito.rd.easywebmail.ui

import android.security.keystore.KeyPermanentlyInvalidatedException
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.portal.PortalEngine
import pt.exercito.rd.easywebmail.portal.PortalStage
import pt.exercito.rd.easywebmail.security.BiometricHelper
import pt.exercito.rd.easywebmail.security.CredentialVault
import pt.exercito.rd.easywebmail.viewmodel.PortalViewModel

/** Ecrã de login nativo (NIM e password). O portal verdadeiro corre numa WebView escondida. */
@Composable
fun LoginScreen(
    viewModel: PortalViewModel,
    onStartListening: () -> Unit
) {
    val context = LocalContext.current
    val stage by PortalEngine.stage.collectAsState()
    val engineError by PortalEngine.errorMessage.collectAsState()

    var nim by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rememberCredentials by remember { mutableStateOf(!CredentialVault.hasCredentials(context)) }
    var showPassword by remember { mutableStateOf(false) }
    var hasSaved by remember { mutableStateOf(CredentialVault.hasCredentials(context)) }
    var localMessage by remember { mutableStateOf<String?>(null) }

    val busy = stage == PortalStage.SUBMITTING_CREDENTIALS
    val connecting = stage == PortalStage.LOADING_LOGIN

    LaunchedEffect(Unit) { PortalEngine.prepare() }

    fun startLogin(user: String, pass: String, remember: Boolean) {
        localMessage = null
        viewModel.clearOtp()
        onStartListening()
        PortalEngine.login(user, pass, remember)
    }

    fun loginWithFingerprint() {
        val activity = context.findActivity() ?: return
        localMessage = null
        try {
            val cipher = CredentialVault.decryptCipher(context)
            BiometricHelper.authenticate(
                activity = activity,
                title = "Entrar no portal",
                subtitle = "Confirme com a impressão digital",
                cipher = cipher,
                onSuccess = { authorized ->
                    val credentials = try {
                        CredentialVault.decrypt(context, authorized)
                    } catch (e: Exception) {
                        null
                    }
                    if (credentials == null) {
                        localMessage = "Não foi possível ler as credenciais memorizadas."
                    } else {
                        startLogin(credentials.first, credentials.second, false)
                    }
                },
                onFailure = { message ->
                    if (message != "Cancelado.") localMessage = message
                }
            )
        } catch (e: KeyPermanentlyInvalidatedException) {
            CredentialVault.clear(context)
            hasSaved = false
            localMessage = "As impressões digitais do telemóvel mudaram. Entre com o NIM e a password e memorize de novo."
        } catch (e: Exception) {
            localMessage = "Não foi possível usar a impressão digital: " + e.localizedMessage
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Pal.bgTop, Pal.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(Pal.card)
                    .border(1.dp, Pal.cardBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VpnKey,
                    contentDescription = null,
                    tint = Pal.gold,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Exército Mobile",
                color = Pal.textMain,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Autenticação multi-fator",
                color = Pal.textSoft,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(28.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Pal.card)
                    .border(1.dp, Pal.cardBorder, RoundedCornerShape(20.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedTextField(
                    value = nim,
                    onValueChange = { nim = it },
                    label = { Text("NIM") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = portalFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(
                                imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (showPassword) "Esconder password" else "Mostrar password"
                            )
                        }
                    },
                    singleLine = true,
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = portalFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = rememberCredentials,
                        onCheckedChange = { rememberCredentials = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Pal.gold,
                            uncheckedColor = Pal.textSoft,
                            checkmarkColor = Color.Black
                        )
                    )
                    Text(
                        text = "Memorizar NIM e password (impressão digital)",
                        color = Pal.textSoft,
                        fontSize = 13.sp
                    )
                }

                val message = localMessage ?: engineError
                if (message != null) {
                    Text(
                        text = message,
                        color = Pal.error,
                        fontSize = 14.sp
                    )
                }

                Button(
                    onClick = { startLogin(nim, password, rememberCredentials) },
                    enabled = nim.isNotBlank() && password.isNotEmpty() && !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Pal.green,
                        contentColor = Color.White
                    )
                ) {
                    if (busy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Entrar", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }

                if (hasSaved) {
                    OutlinedButton(
                        onClick = { loginWithFingerprint() },
                        enabled = !busy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null,
                            tint = Pal.gold
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Entrar com impressão digital", color = Pal.textMain)
                    }
                    TextButton(
                        onClick = {
                            CredentialVault.clear(context)
                            hasSaved = false
                            localMessage = "Credenciais memorizadas apagadas."
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Esquecer credenciais memorizadas", color = Pal.textSoft, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            if (connecting) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Pal.gold,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("A ligar ao portal…", color = Pal.textSoft, fontSize = 12.sp)
                }
            }
        }
    }
}
