package pt.exercito.rd.easywebmail.ui

import android.content.Context
import android.net.Uri
import android.net.http.SslCertificate
import android.net.http.SslError
import android.os.Build
import pt.exercito.rd.easywebmail.R
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

/**
 * O servidor do Portal RD não envia o certificado intermédio da Sectigo, e a WebView do Android
 * não o vai buscar sozinha (ao contrário do Firefox/Chrome), dando SSL_UNTRUSTED.
 *
 * Em vez de ignorar erros de certificado, este validador aceita a ligação SOMENTE se:
 *  - o erro for apenas "não confiável" (SSL_UNTRUSTED);
 *  - o domínio terminar em .rd.exercito.pt;
 *  - o certificado do servidor tiver sido assinado pelo intermédio da Sectigo incluído na app
 *    (Sectigo Public Server Authentication CA OV R36), cuja impressão digital SHA-256 é verificada;
 *  - o certificado estiver dentro da validade e o nome do domínio corresponder.
 *
 * Nota: não verifica revogação (OCSP/CRL).
 */
object PortalCertificateValidator {

    private const val ALLOWED_DOMAIN_SUFFIX = ".rd.exercito.pt"
    private const val INTERMEDIATE_SHA256 = "6542D176BED50F193C0CE297AE44ECD8A0A86BEC2EDE682769344059B4E78530"

    fun isTrusted(context: Context, error: SslError?): Boolean {
        if (error == null || error.primaryError != SslError.SSL_UNTRUSTED) return false
        return try {
            val host = Uri.parse(error.url).host?.lowercase() ?: return false
            if (!host.endsWith(ALLOWED_DOMAIN_SUFFIX)) return false

            val leaf = leafCertificate(error.certificate) ?: return false
            val intermediate = loadIntermediate(context)

            if (sha256(intermediate.encoded) != INTERMEDIATE_SHA256) return false
            intermediate.checkValidity()
            if (intermediate.basicConstraints < 0) return false // tem de ser uma CA

            leaf.checkValidity()
            if (leaf.basicConstraints != -1) return false // o certificado do servidor não pode ser CA
            leaf.verify(intermediate.publicKey) // assinado pelo intermédio da Sectigo?

            hostMatches(leaf, host)
        } catch (e: Exception) {
            false
        }
    }

    private fun loadIntermediate(context: Context): X509Certificate =
        context.resources.openRawResource(R.raw.sectigo_ov_r36).use { stream ->
            CertificateFactory.getInstance("X.509").generateCertificate(stream) as X509Certificate
        }

    private fun leafCertificate(cert: SslCertificate?): X509Certificate? {
        if (cert == null) return null
        if (Build.VERSION.SDK_INT >= 29) return cert.x509Certificate
        val bytes = SslCertificate.saveState(cert).getByteArray("x509-certificate") ?: return null
        return CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(bytes)) as X509Certificate
    }

    private fun hostMatches(cert: X509Certificate, host: String): Boolean {
        val names = cert.subjectAlternativeNames ?: return false
        for (entry in names) {
            if (entry.size < 2 || (entry[0] as? Int) != 2) continue // 2 = nome DNS
            val name = (entry[1] as? String)?.lowercase() ?: continue
            if (nameMatches(name, host)) return true
        }
        return false
    }

    private fun nameMatches(name: String, host: String): Boolean {
        if (name.startsWith("*.")) {
            val suffix = name.substring(1) // ".rd.exercito.pt"
            return host.endsWith(suffix) &&
                host.length > suffix.length &&
                !host.substring(0, host.length - suffix.length).contains('.')
        }
        return host == name
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02X".format(it) }
}
