package pt.exercito.rd.easywebmail.security

import android.app.Activity
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import javax.crypto.Cipher

/** Pede a impressão digital e devolve a cifra autorizada (BiometricPrompt do Android 11+). */
object BiometricHelper {

    // códigos de erro do Android para "o utilizador cancelou"
    private const val ERROR_CANCELED = 5
    private const val ERROR_USER_CANCELED = 10
    private const val ERROR_NEGATIVE_BUTTON = 13

    fun authenticate(
        activity: Activity,
        title: String,
        subtitle: String,
        cipher: Cipher,
        onSuccess: (Cipher) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val signal = CancellationSignal()

        val prompt = BiometricPrompt.Builder(activity)
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButton("Cancelar", executor) { _, _ -> signal.cancel() }
            .build()

        prompt.authenticate(
            BiometricPrompt.CryptoObject(cipher),
            signal,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    val authorized = result.cryptoObject?.cipher
                    if (authorized != null) {
                        onSuccess(authorized)
                    } else {
                        onFailure("Não foi possível autorizar a chave.")
                    }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode == ERROR_CANCELED ||
                        errorCode == ERROR_USER_CANCELED ||
                        errorCode == ERROR_NEGATIVE_BUTTON
                    ) {
                        onFailure("Cancelado.")
                    } else {
                        onFailure(errString.toString())
                    }
                }
            }
        )
    }
}
