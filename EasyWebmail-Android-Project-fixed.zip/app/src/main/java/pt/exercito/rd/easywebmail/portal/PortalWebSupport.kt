package pt.exercito.rd.easywebmail.portal

import android.annotation.SuppressLint
import android.content.Context
import android.net.http.SslError
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import pt.exercito.rd.easywebmail.ui.DebugLog
import pt.exercito.rd.easywebmail.ui.PortalCertificateValidator

/** Configuração comum às WebViews da app (a escondida do login e a visível das aplicações). */
object PortalWebSupport {

    @SuppressLint("SetJavaScriptEnabled")
    fun configure(webView: WebView, interactive: Boolean) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        // Identifica-se como Chrome móvel normal (sem "; wv" nem "Version/x.y").
        settings.userAgentString = settings.userAgentString
            .replace("; wv", "")
            .replace(Regex("Version/\\d+\\.\\d+ "), "")

        // A WebView envia "X-Requested-With: <pacote>" por defeito; o Chrome não.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, emptySet())
        }

        if (interactive) {
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
        }

        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(webView, true)
    }

    /**
     * O servidor do portal não envia o certificado intermédio da Sectigo. Aceita a ligação só se o
     * certificado for assinado por esse intermédio (ver PortalCertificateValidator).
     * Devolve true se a ligação foi aceite.
     */
    fun handleSslError(context: Context, handler: SslErrorHandler?, error: SslError?): Boolean {
        return if (PortalCertificateValidator.isTrusted(context, error)) {
            handler?.proceed()
            true
        } else {
            DebugLog.add("SSL RECUSADO código " + (error?.primaryError ?: -1) + " " + DebugLog.safeUrl(error?.url))
            handler?.cancel()
            false
        }
    }
}
