package pt.exercito.rd.easywebmail.ui

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Cores dos ecrãs de login (verde Exército e dourado). */
object Pal {
    val bgTop = Color(0xFF08150E)
    val bgBottom = Color(0xFF15382B)
    val card = Color(0xFF12241B)
    val cardBorder = Color(0xFF2B4A3A)
    val gold = Color(0xFFDFBF7A)
    val green = Color(0xFF2E7D4F)
    val textMain = Color(0xFFF1F5F9)
    val textSoft = Color(0xFFB8C7BE)
    val error = Color(0xFFFF8A80)
}

@Composable
fun portalFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Pal.gold,
    unfocusedBorderColor = Pal.cardBorder,
    focusedLabelColor = Pal.gold,
    unfocusedLabelColor = Pal.textSoft,
    cursorColor = Pal.gold,
    focusedLeadingIconColor = Pal.gold,
    unfocusedLeadingIconColor = Pal.textSoft,
    focusedTrailingIconColor = Pal.gold,
    unfocusedTrailingIconColor = Pal.textSoft
)
