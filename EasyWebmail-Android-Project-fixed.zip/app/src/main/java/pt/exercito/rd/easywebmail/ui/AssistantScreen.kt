package pt.exercito.rd.easywebmail.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

/**
 * Ecrã principal: a app trata só do código SMS; o portal e o webmail abrem no browser do telemóvel.
 */
@Composable
fun AssistantScreen(
    viewModel: WebViewModel,
    onStartListening: () -> Unit,
    onOpenInApp: () -> Unit = {}
) {
    val context = LocalContext.current
    val smsStatus by viewModel.smsStatus.collectAsState()
    val otp by viewModel.lastReceivedOtp.collectAsState()

    val gold = Color(0xFFDFBF7A)
    val textMain = Color(0xFFF1F5F9)
    val textSoft = Color(0xFFCBD5E1)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F241A))
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Assistente de código SMS",
            color = textMain,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "O portal e o webmail abrem no seu browser. Esta app trata só do código SMS.",
            color = textSoft,
            fontSize = 14.sp
        )

        Button(
            onClick = {
                onStartListening()
                openPortalInBrowser(context)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2E7D4F),
                contentColor = Color.White
            )
        ) {
            Text("Abrir portal e aguardar SMS", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = onOpenInApp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Experimental: abrir o portal dentro da app", color = textMain)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Como funciona", color = gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("1. Toque no botão: o portal abre no browser.", color = textMain, fontSize = 14.sp)
                Text("2. Faça login com o NIM e a password.", color = textMain, fontSize = 14.sp)
                Text(
                    "3. Quando chegar o SMS, toque na notificação \"Código SMS recebido\" e autorize. O código fica copiado.",
                    color = textMain,
                    fontSize = 14.sp
                )
                Text("4. Volte ao browser e cole o código.", color = textMain, fontSize = 14.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Estado", color = gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(smsStatus, color = textMain, fontSize = 14.sp)

                otp?.let { code ->
                    Text(
                        text = code,
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    OutlinedButton(
                        onClick = {
                            copySensitiveText(context, code)
                            Toast.makeText(context, "Código copiado", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Copiar de novo", color = textMain)
                    }
                }
            }
        }

        Text(
            text = "A leitura do SMS é pedida ao Google Play Services: uma mensagem de cada vez, com a sua autorização. " +
                "A app não tem permissão para ler os seus SMS.",
            color = Color(0xFF94A3B8),
            fontSize = 12.sp
        )
    }
}

private fun openPortalInBrowser(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(WebViewModel.PORTAL_LOGIN_URL))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi encontrado nenhum browser", Toast.LENGTH_LONG).show()
    }
}
