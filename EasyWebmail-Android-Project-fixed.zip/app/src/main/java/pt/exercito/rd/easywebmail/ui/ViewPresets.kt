package pt.exercito.rd.easywebmail.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.webkit.WebView
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray

enum class UaMode { CHROME_MOBILE, CHROME_DESKTOP, FIREFOX_MOBILE }

/** Uma combinação de definições de visualização para testar o webmail. */
data class ViewPreset(
    val name: String,
    val ua: UaMode = UaMode.CHROME_MOBILE,
    /** Largura do viewport em px CSS; null = a que a página pede (largura do ecrã). */
    val viewportWidth: Int? = null,
    val wideViewPort: Boolean = true,
    val overview: Boolean = true,
    val software: Boolean = false,
    /** Força html/body a ocupar 100% da altura depois de a página carregar. */
    val fixHeight: Boolean = false
)

object ViewPresets {

    val all: List<ViewPreset> = listOf(
        ViewPreset("Chrome móvel · normal"),
        ViewPreset("Chrome móvel · desenho por software", software = true),
        ViewPreset("Chrome móvel · altura 100% forçada", fixHeight = true),
        ViewPreset("Chrome móvel · sem viewport largo", wideViewPort = false, overview = false),
        ViewPreset("Chrome móvel · viewport 800", viewportWidth = 800),
        ViewPreset("Chrome móvel · viewport 1024", viewportWidth = 1024),
        ViewPreset("Chrome móvel · viewport 1280", viewportWidth = 1280),
        ViewPreset("Chrome móvel · 1024 + altura 100%", viewportWidth = 1024, fixHeight = true),
        ViewPreset("Chrome desktop · normal", ua = UaMode.CHROME_DESKTOP),
        ViewPreset("Chrome desktop · viewport 1280", ua = UaMode.CHROME_DESKTOP, viewportWidth = 1280),
        ViewPreset(
            "Chrome desktop · 1280 + altura 100%",
            ua = UaMode.CHROME_DESKTOP, viewportWidth = 1280, fixHeight = true
        ),
        ViewPreset("Firefox móvel · normal", ua = UaMode.FIREFOX_MOBILE),
        ViewPreset("Firefox móvel · viewport 1024", ua = UaMode.FIREFOX_MOBILE, viewportWidth = 1024),
        ViewPreset(
            "Firefox móvel · 1024 + software + altura 100%",
            ua = UaMode.FIREFOX_MOBILE, viewportWidth = 1024, software = true, fixHeight = true
        )
    )

    private const val PREFS = "view_presets"
    private const val KEY_INDEX = "index"

    fun savedIndex(context: Context): Int {
        val index = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_INDEX, 0)
        return if (index in all.indices) index else 0
    }

    fun saveIndex(context: Context, index: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_INDEX, index).apply()
    }

    private val FIX_HEIGHT_JS = """
        (function(){
          var h = document.documentElement, b = document.body;
          if (h) { h.style.height = '100%'; }
          if (b) { b.style.height = '100%'; b.style.minHeight = '100%'; }
          return 'ok';
        })()
    """.trimIndent()

    val PROBE_JS = """
        (function(){
          var r = {};
          var h = document.documentElement, b = document.body;
          r.htmlH = h ? Math.round(h.getBoundingClientRect().height) : -1;
          r.bodyH = b ? Math.round(b.getBoundingClientRect().height) : -1;
          r.win = window.innerWidth + 'x' + window.innerHeight;
          r.text = b ? (b.innerText || '').length : -1;
          return JSON.stringify(r);
        })()
    """.trimIndent()

    /** Estrutura da página (etiqueta, posição, tamanho e visibilidade), sem texto nem dados. */
    val INSPECT_JS = """
        (function(){
          function d(e){
            var s = e.tagName.toLowerCase();
            if (e.id) s += '#' + e.id;
            if (e.className && typeof e.className === 'string') s += '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.');
            return s;
          }
          function info(e){
            var c = getComputedStyle(e), b = e.getBoundingClientRect();
            return d(e) + ' [' + Math.round(b.left) + ',' + Math.round(b.top) + ' ' + Math.round(b.width) + 'x' + Math.round(b.height) + '] ' +
              c.display + '/' + c.position + '/ov:' + c.overflow + '/vis:' + c.visibility + '/op:' + c.opacity;
          }
          var out = [];
          var skip = ['SCRIPT', 'STYLE', 'LINK', 'META', 'NOSCRIPT', 'TITLE', 'HEAD'];
          function walk(e, depth){
            if (depth > 3) return;
            out.push(new Array(depth + 1).join('  ') + info(e));
            var ch = e.children;
            for (var i = 0; i < ch.length && i < 12; i++) {
              if (skip.indexOf(ch[i].tagName) >= 0) continue;
              walk(ch[i], depth + 1);
            }
          }
          walk(document.documentElement, 0);
          out.push('iframes: ' + document.getElementsByTagName('iframe').length);
          return out.slice(0, 80).join('\n');
        })()
    """.trimIndent()

    private fun viewportScript(width: Int): String = """
        (function(){
          if (location.pathname.indexOf('/owa/') !== 0) return;
          var W = $width;
          var done = false;
          function fix(){
            var m = document.querySelector('meta[name=viewport]');
            if (m) { m.setAttribute('content', 'width=' + W + ', user-scalable=yes'); done = true; }
          }
          fix();
          var obs = new MutationObserver(function(){ if (done) { obs.disconnect(); } else { fix(); } });
          obs.observe(document, {childList: true, subtree: true});
          document.addEventListener('DOMContentLoaded', fix);
        })();
    """.trimIndent()

    /** Aplica um conjunto de definições a uma WebView (vale a partir do próximo carregamento). */
    class Applier(private val webView: WebView, private val baseUserAgent: String) {
        private var handler: ScriptHandler? = null

        private fun userAgentFor(mode: UaMode): String = when (mode) {
            UaMode.CHROME_MOBILE -> baseUserAgent
            UaMode.CHROME_DESKTOP -> {
                val version = Regex("Chrome/([0-9.]+)").find(baseUserAgent)?.groupValues?.get(1) ?: "120.0.0.0"
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/$version Safari/537.36"
            }
            UaMode.FIREFOX_MOBILE -> "Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0"
        }

        fun applyPreset(preset: ViewPreset) {
            val settings = webView.settings
            settings.userAgentString = userAgentFor(preset.ua)
            settings.useWideViewPort = preset.wideViewPort
            settings.loadWithOverviewMode = preset.overview
            webView.setLayerType(
                if (preset.software) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_NONE,
                null
            )
            handler?.remove()
            handler = null
            val width = preset.viewportWidth
            if (width != null && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                handler = WebViewCompat.addDocumentStartJavaScript(
                    webView, viewportScript(width), setOf("https://*.rd.exercito.pt")
                )
            }
            DebugLog.add("VISUALIZAÇÃO: " + preset.name)
        }

        /** Corre depois de a página carregar (por exemplo, forçar a altura). */
        fun afterLoad(preset: ViewPreset) {
            if (!preset.fixHeight) return
            for (delayMs in longArrayOf(2000L, 6000L)) {
                webView.postDelayed({ webView.evaluateJavascript(FIX_HEIGHT_JS, null) }, delayMs)
            }
        }
    }
}

/** Percentagem de pixels que não são brancos, desenhando a WebView por software. */
fun nonWhitePercent(webView: WebView): Int {
    return try {
        val w = webView.width
        val h = webView.height
        if (w <= 0 || h <= 0) return -1
        val scale = 0.25f
        val bmp = Bitmap.createBitmap(
            (w * scale).toInt().coerceAtLeast(1),
            (h * scale).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bmp)
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.scale(scale, scale)
        webView.draw(canvas)
        val pixels = IntArray(bmp.width * bmp.height)
        bmp.getPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        var nonWhite = 0
        for (p in pixels) {
            if ((p and 0x00FFFFFF) != 0x00FFFFFF) nonWhite++
        }
        bmp.recycle()
        if (pixels.isEmpty()) 0 else nonWhite * 100 / pixels.size
    } catch (e: Exception) {
        -1
    }
}

/** Corre JavaScript e devolve o resultado (texto) de forma suspensa. */
suspend fun evalJsSuspend(webView: WebView, script: String): String? =
    suspendCancellableCoroutine { continuation ->
        webView.evaluateJavascript(script) { raw ->
            if (continuation.isActive) continuation.resume(raw)
        }
    }

/** Converte o texto devolvido por evaluateJavascript (entre aspas, com escapes) em texto normal. */
fun unquoteJs(raw: String?): String {
    if (raw == null || raw == "null") return ""
    return try {
        JSONArray("[$raw]").optString(0)
    } catch (e: Exception) {
        raw
    }
}
