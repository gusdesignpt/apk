package pt.exercito.rd.easywebmail.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.webkit.ConsoleMessage
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import pt.exercito.rd.easywebmail.portal.PortalLink
import pt.exercito.rd.easywebmail.portal.PortalWebSupport

private const val SWEEP_WAIT_MS = 30_000L

/**
 * Abre a aplicação escolhida (ex.: Webmail) dentro da app, com a sessão já iniciada pelo motor de
 * login: os cookies são partilhados entre as WebViews da app, por isso não pede novo login.
 *
 * O ícone de ajustes abre o "teste de visualização": experimenta, uma a uma ou em sequência,
 * várias combinações de resolução e definições até o webmail aparecer.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppBrowserScreen(
    link: PortalLink,
    onClose: () -> Unit,
    onSessionExpired: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var applier by remember { mutableStateOf<ViewPresets.Applier?>(null) }
    var progress by remember { mutableStateOf(0) }

    var testerOpen by remember { mutableStateOf(false) }
    var presetIndex by remember { mutableStateOf(ViewPresets.savedIndex(context)) }
    var sweeping by remember { mutableStateOf(false) }
    var sweepJob by remember { mutableStateOf<Job?>(null) }
    val results = remember { mutableStateListOf<String>() }

    fun loadPreset(index: Int) {
        val wv = webViewRef ?: return
        val currentApplier = applier ?: return
        presetIndex = index
        currentApplier.applyPreset(ViewPresets.all[index])
        wv.loadUrl(link.url)
    }

    fun stopSweep() {
        sweepJob?.cancel()
        sweepJob = null
        sweeping = false
    }

    fun startSweep() {
        stopSweep()
        results.clear()
        sweeping = true
        sweepJob = scope.launch {
            try {
                for (i in ViewPresets.all.indices) {
                    loadPreset(i)
                    delay(SWEEP_WAIT_MS)
                    val wv = webViewRef ?: break
                    val percent = nonWhitePercent(wv)
                    val probe = summarizeProbe(evalJsSuspend(wv, ViewPresets.PROBE_JS))
                    val ok = percent >= 3
                    val line = (if (ok) "✔ " else "✘ ") + (i + 1) + ". " + ViewPresets.all[i].name +
                        " — " + percent + "% visível; " + probe
                    results.add(line)
                    DebugLog.add("TESTE $line")
                }
            } finally {
                sweeping = false
            }
        }
    }

    fun inspectPage() {
        val wv = webViewRef ?: return
        scope.launch {
            val text = unquoteJs(evalJsSuspend(wv, ViewPresets.INSPECT_JS))
            DebugLog.add("INSPECIONAR\n" + text)
            results.clear()
            results.addAll(text.lines().ifEmpty { listOf("sem resposta") })
        }
    }

    BackHandler(enabled = true) {
        val wv = webViewRef
        if (wv != null && wv.canGoBack()) wv.goBack() else onClose()
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Pal.bgBottom)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
            }
            Text(
                text = link.title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { testerOpen = !testerOpen }) {
                Icon(
                    Icons.Default.Tune,
                    contentDescription = "Teste de visualização",
                    tint = if (testerOpen) Pal.gold else Color.White
                )
            }
            IconButton(onClick = { webViewRef?.reload() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Recarregar", tint = Color.White)
            }
            IconButton(onClick = {
                val current = webViewRef?.url
                if (current != null) {
                    Toast.makeText(
                        context,
                        "No browser vai pedir novo login: a sessão não passa da app para o browser.",
                        Toast.LENGTH_LONG
                    ).show()
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(current)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                        Toast.makeText(context, "Não foi encontrado nenhum browser", Toast.LENGTH_SHORT).show()
                    }
                }
            }) {
                Icon(Icons.Default.OpenInBrowser, contentDescription = "Abrir no browser", tint = Color.White)
            }
        }

        if (testerOpen) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Teste de visualização",
                    color = Pal.gold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${presetIndex + 1}/${ViewPresets.all.size} · ${ViewPresets.all[presetIndex].name}",
                    color = Color.White,
                    fontSize = 13.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (presetIndex > 0) loadPreset(presetIndex - 1) },
                        enabled = !sweeping
                    ) { Text("◀", color = Color.White) }
                    OutlinedButton(
                        onClick = { loadPreset(presetIndex) },
                        enabled = !sweeping
                    ) { Text("Aplicar", color = Color.White) }
                    OutlinedButton(
                        onClick = { if (presetIndex < ViewPresets.all.size - 1) loadPreset(presetIndex + 1) },
                        enabled = !sweeping
                    ) { Text("▶", color = Color.White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (sweeping) {
                        Button(
                            onClick = { stopSweep() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B2E2E))
                        ) { Text("Parar") }
                    } else {
                        Button(
                            onClick = { startSweep() },
                            colors = ButtonDefaults.buttonColors(containerColor = Pal.green)
                        ) { Text("Testar todos") }
                    }
                    OutlinedButton(
                        onClick = { inspectPage() },
                        enabled = !sweeping
                    ) { Text("Inspecionar", color = Color.White) }
                }
                OutlinedButton(
                    onClick = {
                        ViewPresets.saveIndex(context, presetIndex)
                        Toast.makeText(context, "Guardado como predefinição", Toast.LENGTH_SHORT).show()
                    }
                ) { Text("Usar sempre este", color = Color.White) }
                if (sweeping) {
                    Text(
                        text = "A testar uma combinação de cada vez (cerca de 30 s cada). Não feche esta janela.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )
                }
                if (results.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 150.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        results.forEach { line ->
                            Text(text = line, color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = Pal.gold
            )
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    PortalWebSupport.configure(this, interactive = true)

                    val presetApplier = ViewPresets.Applier(this, settings.userAgentString)
                    applier = presetApplier
                    presetApplier.applyPreset(ViewPresets.all[presetIndex])

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            DebugLog.add("APP PAGE START " + DebugLog.safeUrl(url))
                            if (url != null && url.contains("/Login/Login")) {
                                onSessionExpired()
                            }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            DebugLog.add("APP PAGE FINISH " + DebugLog.safeUrl(url))
                            presetApplier.afterLoad(ViewPresets.all[presetIndex])
                        }

                        override fun onReceivedHttpError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            errorResponse: WebResourceResponse?
                        ) {
                            DebugLog.add(
                                "APP HTTP " + (errorResponse?.statusCode ?: 0) + " " +
                                    (if (request?.isForMainFrame == true) "[principal] " else "[recurso] ") +
                                    DebugLog.safeUrl(request?.url?.toString())
                            )
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            DebugLog.add(
                                "APP ERRO REDE " + (error?.errorCode ?: 0) + " " + (error?.description ?: "?") + " " +
                                    DebugLog.safeUrl(request?.url?.toString())
                            )
                        }

                        override fun onReceivedSslError(
                            view: WebView?,
                            handler: SslErrorHandler?,
                            error: SslError?
                        ) {
                            PortalWebSupport.handleSslError(ctx, handler, error)
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val uri = request?.url ?: return false
                            val scheme = uri.scheme ?: return false
                            if (scheme == "http" || scheme == "https") return false
                            try {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) {
                                // sem aplicação para este tipo de ligação
                            }
                            return true
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }

                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            if (consoleMessage != null &&
                                consoleMessage.messageLevel() != ConsoleMessage.MessageLevel.LOG &&
                                consoleMessage.messageLevel() != ConsoleMessage.MessageLevel.TIP
                            ) {
                                DebugLog.add(
                                    "APP CONSOLA " + consoleMessage.messageLevel() + ": " +
                                        consoleMessage.message().take(250) + " @" +
                                        DebugLog.safeUrl(consoleMessage.sourceId()) + ":" + consoleMessage.lineNumber()
                                )
                            }
                            return false
                        }
                    }

                    webViewRef = this
                    loadUrl(link.url)
                }
            }
        )
    }
}

/** Resume o resultado da sonda ao DOM (altura do html e tamanho da janela). */
private fun summarizeProbe(raw: String?): String {
    if (raw == null || raw == "null") return "sem resposta"
    return try {
        val text = JSONArray("[$raw]").optString(0)
        val obj = JSONObject(text)
        "html " + obj.optInt("htmlH", -1) + "px, janela " + obj.optString("win", "?")
    } catch (e: Exception) {
        "sonda ilegível"
    }
}
