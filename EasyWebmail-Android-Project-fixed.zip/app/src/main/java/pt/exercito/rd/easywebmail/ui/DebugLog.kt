package pt.exercito.rd.easywebmail.ui

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.WebView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registo de diagnóstico em memória, que pode ser guardado como .txt na pasta Downloads.
 *
 * Privacidade: NÃO regista passwords, cookies, cabeçalhos nem corpo de pedidos. Os endereços são
 * guardados sem parâmetros (tudo a seguir a "?" ou "#" é removido) e sequências de 6 ou mais
 * dígitos (ex.: códigos OTP) são substituídas por ***.
 */
object DebugLog {

    private const val MAX_LINES = 2000
    private val lines = ArrayList<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var lastMsg: String? = null
    private var lastCount = 1

    private val digitsRegex = Regex("\\d{6,}")

    private fun redact(text: String): String = digitsRegex.replace(text, "***")

    /** Endereço sem parâmetros nem fragmento. */
    fun safeUrl(url: String?): String {
        if (url.isNullOrEmpty()) return ""
        val cut = url.indexOfFirst { it == '?' || it == '#' }
        val base = if (cut >= 0) url.substring(0, cut) + (if (url[cut] == '?') "?…" else "#…") else url
        return redact(base).take(160)
    }

    @Synchronized
    fun add(message: String) {
        val msg = redact(message)
        if (msg == lastMsg && lines.isNotEmpty()) {
            lastCount++
            val last = lines.removeAt(lines.size - 1)
            val base = last.substringBefore("  [x")
            lines.add(base + "  [x" + lastCount + "]")
            return
        }
        lastMsg = msg
        lastCount = 1
        lines.add(timeFormat.format(Date()) + "  " + msg)
        if (lines.size > MAX_LINES) lines.removeAt(0)
    }

    @Synchronized
    fun clear() {
        lines.clear()
        lastMsg = null
        lastCount = 1
    }

    @Synchronized
    private fun body(): String = lines.joinToString("\n")

    private fun header(): String {
        val webViewVersion = try {
            WebView.getCurrentWebViewPackage()?.let { it.packageName + " " + it.versionName } ?: "?"
        } catch (e: Exception) {
            "?"
        }
        return "EasyWebmail - registo de diagnóstico\n" +
            "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), " +
            Build.MANUFACTURER + " " + Build.MODEL + "\n" +
            "WebView: " + webViewVersion + "\n" +
            "Gerado em: " + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + "\n" +
            "----------------------------------------\n"
    }

    /**
     * Guarda o registo num ficheiro .txt. Em Android 10+ vai para a pasta Downloads;
     * em versões anteriores vai para a pasta Download da própria app.
     * Devolve uma descrição do local guardado, ou null se falhar.
     */
    fun saveToDownloads(context: Context): String? {
        val name = "EasyWebmail_debug_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val content = (header() + body() + "\n").toByteArray(Charsets.UTF_8)
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                resolver.openOutputStream(uri)?.use { it.write(content) } ?: return null
                "Downloads/$name"
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return null
                val file = File(dir, name)
                file.writeBytes(content)
                file.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
