package pt.exercito.rd.easywebmail.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Guarda o NIM e a password cifrados com uma chave AES-256-GCM do Android Keystore.
 * A chave nunca sai do hardware seguro e só pode ser usada depois de uma autenticação
 * biométrica (impressão digital) por cada utilização.
 *
 * Se as impressões digitais registadas no telemóvel mudarem, a chave deixa de ser válida
 * e as credenciais têm de ser memorizadas outra vez.
 */
object CredentialVault {

    private const val KEY_ALIAS = "easywebmail_credentials_key"
    private const val PREFS = "credentials_vault"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val PREF_IV = "iv"
    private const val PREF_DATA = "data"
    private const val PREF_SAVED_AT = "saved_at"
    private const val SEPARATOR = '\u0000'

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun keyStore(): KeyStore =
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun createKey(): SecretKey {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun getOrCreateKey(): SecretKey {
        val existing = keyStore().getKey(KEY_ALIAS, null) as? SecretKey
        return existing ?: createKey()
    }

    fun hasCredentials(context: Context): Boolean =
        prefs(context).contains(PREF_DATA) && prefs(context).contains(PREF_IV)

    /** Data (em milissegundos) em que as credenciais foram memorizadas, ou 0. */
    fun savedAt(context: Context): Long = prefs(context).getLong(PREF_SAVED_AT, 0L)

    /** Cifra pronta para cifrar; tem de ser autorizada com a impressão digital antes de usar. */
    fun encryptCipher(): Cipher {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        try {
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        } catch (e: KeyPermanentlyInvalidatedException) {
            // impressões digitais mudaram: apaga a chave antiga e cria uma nova
            keyStore().deleteEntry(KEY_ALIAS)
            cipher.init(Cipher.ENCRYPT_MODE, createKey())
        }
        return cipher
    }

    /**
     * Cifra pronta para decifrar; tem de ser autorizada com a impressão digital antes de usar.
     * Pode lançar KeyPermanentlyInvalidatedException se as impressões digitais mudaram.
     */
    fun decryptCipher(context: Context): Cipher {
        val ivText = prefs(context).getString(PREF_IV, null)
            ?: throw IllegalStateException("Não há credenciais memorizadas")
        val iv = Base64.decode(ivText, Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher
    }

    fun save(context: Context, cipher: Cipher, nim: String, password: String) {
        val payload = (nim + SEPARATOR + password).toByteArray(Charsets.UTF_8)
        val encrypted = cipher.doFinal(payload)
        prefs(context).edit()
            .putString(PREF_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(PREF_DATA, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putLong(PREF_SAVED_AT, System.currentTimeMillis())
            .apply()
    }

    /** Devolve (NIM, password) ou null se não for possível ler. */
    fun decrypt(context: Context, cipher: Cipher): Pair<String, String>? {
        val dataText = prefs(context).getString(PREF_DATA, null) ?: return null
        val plain = cipher.doFinal(Base64.decode(dataText, Base64.NO_WRAP))
        val parts = String(plain, Charsets.UTF_8).split(SEPARATOR, limit = 2)
        if (parts.size != 2) return null
        return Pair(parts[0], parts[1])
    }

    fun clear(context: Context) {
        prefs(context).edit().clear().apply()
        try {
            keyStore().deleteEntry(KEY_ALIAS)
        } catch (e: Exception) {
            // nada a fazer
        }
    }
}
