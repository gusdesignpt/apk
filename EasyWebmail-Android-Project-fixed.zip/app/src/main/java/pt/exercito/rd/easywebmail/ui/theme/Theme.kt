package pt.exercito.rd.easywebmail.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta Oficial Exército Português
val ExercitoGreenDark = Color(0xFF0F241A)
val ExercitoGreenPrimary = Color(0xFF1B382B)
val ExercitoGreenAccent = Color(0xFF2E634D)
val ExercitoGold = Color(0xFFC5A059)
val ExercitoGoldLight = Color(0xFFDFBF7A)

val DarkColorScheme = darkColorScheme(
    primary = ExercitoGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = ExercitoGreenDark,
    onPrimaryContainer = ExercitoGoldLight,
    secondary = ExercitoGold,
    onSecondary = Color(0xFF1E293B),
    background = Color(0xFF0A0F0D),
    surface = Color(0xFF151D19),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
)

@Composable
fun EasyWebmailTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
