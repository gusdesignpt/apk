package pt.exercito.rd.easywebmail

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import pt.exercito.rd.easywebmail.portal.PortalEngine
import pt.exercito.rd.easywebmail.sms.SmsBridge
import pt.exercito.rd.easywebmail.ui.EasyWebmailApp
import pt.exercito.rd.easywebmail.ui.theme.EasyWebmailTheme
import pt.exercito.rd.easywebmail.viewmodel.PortalViewModel

/**
 * EasyWebmail - acesso ao Portal RD do Exército com ecrãs nativos.
 *
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 *
 * O login (NIM, password e código SMS) é feito em ecrãs nativos; o portal verdadeiro corre numa
 * WebView escondida (PortalEngine). O código SMS é obtido com a SMS User Consent API, que pede
 * autorização ao utilizador para cada mensagem e não exige permissões de leitura de SMS.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "EasyWebmail"
    }

    private val viewModel: PortalViewModel by viewModels()

    private val smsConsentLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            handleSmsConsentResult(result.resultCode, result.data)
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                viewModel.updateSmsStatus(
                    "Sem permissão de notificações: se a app estiver em segundo plano, não será avisado do SMS."
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PortalEngine.init(applicationContext)
        SmsBridge.ensureChannel(this)
        SmsBridge.statusHandler = { viewModel.updateSmsStatus(it) }

        requestNotificationPermissionIfNeeded()
        handleConsentIntent(intent)

        setContent {
            EasyWebmailTheme {
                EasyWebmailApp(
                    viewModel = viewModel,
                    onStartListening = { startSmsUserConsentListener() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleConsentIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        // Com a app visível, a janela de consentimento abre logo que o SMS chega.
        SmsBridge.foregroundHandler = { consentIntent -> launchConsent(consentIntent) }
    }

    override fun onStop() {
        SmsBridge.foregroundHandler = null
        super.onStop()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Se a app foi aberta ao tocar na notificação, abre a janela de consentimento da Google. */
    private fun handleConsentIntent(source: Intent?) {
        if (source == null) return
        @Suppress("DEPRECATION")
        val consent: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            source.getParcelableExtra(SmsBridge.EXTRA_CONSENT_INTENT, Intent::class.java)
        } else {
            source.getParcelableExtra(SmsBridge.EXTRA_CONSENT_INTENT)
        }
        if (consent != null) {
            source.removeExtra(SmsBridge.EXTRA_CONSENT_INTENT)
            launchConsent(consent)
        }
    }

    private fun launchConsent(consentIntent: Intent) {
        try {
            smsConsentLauncher.launch(consentIntent)
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "Erro ao abrir a janela de consentimento de SMS", e)
            viewModel.updateSmsStatus("Não foi possível abrir a janela de autorização do SMS.")
        }
    }

    /**
     * Inicia a escuta do SMS (a API fica à escuta durante 5 minutos).
     * senderPhoneNumber = null aceita o SMS de qualquer remetente.
     */
    private fun startSmsUserConsentListener() {
        SmsRetriever.getClient(this).startSmsUserConsent(null)
            .addOnSuccessListener {
                viewModel.updateSmsStatus("À espera do SMS (até 5 minutos)…")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Falha ao iniciar SMS User Consent API", e)
                viewModel.updateSmsStatus("Erro ao iniciar a escuta de SMS: ${e.localizedMessage}")
            }
    }

    private fun handleSmsConsentResult(resultCode: Int, data: Intent?) {
        SmsBridge.cancelNotification(this)
        when (resultCode) {
            Activity.RESULT_OK -> {
                val message = data?.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE)
                val otp = if (message.isNullOrBlank()) null else extractOtpCode(message)
                if (otp != null) {
                    viewModel.onOtpReceived(otp)
                } else {
                    viewModel.updateSmsStatus("SMS recebido, mas não foi encontrado um código de 6 dígitos.")
                }
            }
            Activity.RESULT_CANCELED -> {
                viewModel.updateSmsStatus("Autorização de leitura do SMS cancelada. Introduza o código à mão.")
            }
        }
    }

    /** Extrai um código numérico de 6 dígitos do corpo do SMS. */
    private fun extractOtpCode(message: String): String? {
        return Regex("\\b(\\d{6})\\b").find(message)?.value
    }
}
