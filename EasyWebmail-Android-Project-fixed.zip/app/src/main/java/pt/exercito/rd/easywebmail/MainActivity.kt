package pt.exercito.rd.easywebmail

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import pt.exercito.rd.easywebmail.sms.SmsBridge
import pt.exercito.rd.easywebmail.ui.EasyWebmailApp
import pt.exercito.rd.easywebmail.ui.copySensitiveText
import pt.exercito.rd.easywebmail.ui.theme.EasyWebmailTheme
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

/**
 * EasyWebmail - assistente do código SMS do Portal RD do Exército.
 *
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 *
 * O portal abre no browser do telemóvel. Esta Activity inicia a escuta da SMS User Consent API,
 * mostra a janela de consentimento da Google quando o SMS chega e copia o código de 6 dígitos
 * para a área de transferência.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "EasyWebmail"
    }

    private val viewModel: WebViewModel by viewModels()

    private val smsConsentLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            handleSmsConsentResult(result.resultCode, result.data)
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                viewModel.updateSmsStatus(
                    "Sem permissão de notificações: a app não o vai avisar quando o SMS chegar."
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        SmsBridge.ensureChannel(this)
        SmsBridge.statusHandler = { viewModel.updateSmsStatus(it) }
        viewModel.updateSmsStatus("Pronto. Toque no botão para abrir o portal e aguardar o SMS.")

        requestNotificationPermissionIfNeeded()
        handleConsentIntent(intent)

        setContent {
            EasyWebmailTheme {
                EasyWebmailApp(
                    viewModel = viewModel,
                    onStartListening = { startSmsUserConsentListener() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleConsentIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        // Com a app visível, a janela de consentimento abre logo que o SMS chega.
        SmsBridge.foregroundHandler = { consentIntent -> launchConsent(consentIntent) }
    }

    override fun onStop() {
        SmsBridge.foregroundHandler = null
        super.onStop()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Se a app foi aberta ao tocar na notificação, abre a janela de consentimento da Google. */
    private fun handleConsentIntent(source: Intent?) {
        if (source == null) return
        @Suppress("DEPRECATION")
        val consent: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            source.getParcelableExtra(SmsBridge.EXTRA_CONSENT_INTENT, Intent::class.java)
        } else {
            source.getParcelableExtra(SmsBridge.EXTRA_CONSENT_INTENT)
        }
        if (consent != null) {
            source.removeExtra(SmsBridge.EXTRA_CONSENT_INTENT)
            launchConsent(consent)
        }
    }

    private fun launchConsent(consentIntent: Intent) {
        try {
            smsConsentLauncher.launch(consentIntent)
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "Erro ao abrir a janela de consentimento de SMS", e)
            viewModel.updateSmsStatus("Não foi possível abrir a janela de autorização do SMS.")
        }
    }

    /**
     * Inicia a escuta do SMS (a API fica à escuta durante 5 minutos).
     * senderPhoneNumber = null aceita o SMS de qualquer remetente.
     */
    private fun startSmsUserConsentListener() {
        SmsRetriever.getClient(this).startSmsUserConsent(null)
            .addOnSuccessListener {
                viewModel.updateSmsStatus("À espera do SMS (até 5 minutos). Faça login no browser.")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Falha ao iniciar SMS User Consent API", e)
                viewModel.updateSmsStatus("Erro ao iniciar a escuta de SMS: ${e.localizedMessage}")
            }
    }

    private fun handleSmsConsentResult(resultCode: Int, data: Intent?) {
        SmsBridge.cancelNotification(this)
        when (resultCode) {
            Activity.RESULT_OK -> {
                val message = data?.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE)
                val otp = if (message.isNullOrBlank()) null else extractOtpCode(message)
                if (otp != null) {
                    viewModel.onOtpReceived(otp)
                    copySensitiveText(this, otp)
                    viewModel.updateSmsStatus("Código copiado. Volte ao browser e cole-o no campo.")
                    Toast.makeText(this, "Código copiado. Cole-o no browser.", Toast.LENGTH_LONG).show()
                } else {
                    viewModel.updateSmsStatus("SMS recebido, mas não foi encontrado um código de 6 dígitos.")
                }
            }
            Activity.RESULT_CANCELED -> {
                viewModel.updateSmsStatus("Autorização de leitura do SMS cancelada.")
            }
        }
    }

    /** Extrai um código numérico de 6 dígitos do corpo do SMS. */
    private fun extractOtpCode(message: String): String? {
        return Regex("\\b(\\d{6})\\b").find(message)?.value
    }
}
