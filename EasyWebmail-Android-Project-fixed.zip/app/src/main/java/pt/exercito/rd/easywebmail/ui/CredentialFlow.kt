package pt.exercito.rd.easywebmail.ui

import android.content.Context
import android.widget.Toast
import pt.exercito.rd.easywebmail.security.BiometricHelper
import pt.exercito.rd.easywebmail.security.CredentialVault

/** Pede a impressão digital e memoriza o NIM e a password cifrados. */
fun saveCredentialsWithFingerprint(context: Context, nim: String, password: String) {
    val activity = context.findActivity() ?: return
    try {
        val cipher = CredentialVault.encryptCipher()
        BiometricHelper.authenticate(
            activity = activity,
            title = "Memorizar credenciais",
            subtitle = "Confirme com a impressão digital para guardar o NIM e a password",
            cipher = cipher,
            onSuccess = { authorized ->
                try {
                    CredentialVault.save(context, authorized, nim, password)
                    Toast.makeText(context, "Credenciais memorizadas", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Não foi possível memorizar: " + e.localizedMessage, Toast.LENGTH_LONG).show()
                }
            },
            onFailure = { message ->
                Toast.makeText(context, "Credenciais não memorizadas: $message", Toast.LENGTH_LONG).show()
            }
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Não foi possível preparar a memorização: " + e.localizedMessage, Toast.LENGTH_LONG).show()
    }
}
