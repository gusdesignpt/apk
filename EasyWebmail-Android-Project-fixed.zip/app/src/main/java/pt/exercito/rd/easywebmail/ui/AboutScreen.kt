package pt.exercito.rd.easywebmail.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Ecrã "Sobre a app" (About Screen).
 * 
 * Explica o funcionamento do EasyWebmail, a integração de segurança com a SMS User Consent API,
 * a cópia do código para a área de transferência e os requisitos de configuração de duplo fator na Intranet.
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
@Composable
fun AboutScreen(
    onNavigateBack: () -> Unit,
    onSaveLog: (() -> Unit)? = null
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Cartão de Cabeçalho
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFFC5A059),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "EasyWebmail",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Acesso Seguro ao Portal RD do Exército Português",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFF334155))
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Desenvolvido por SCh Cav Agostinho Fernandes 2026",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFC5A059)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Secção: Requisito Obrigatório da Intranet
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Requisito Prévio Obrigatório",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFDE68A),
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Para que a autenticação funcione com sucesso, é obrigatório que o utilizador ative previamente o sistema de autenticação por duplo fator através da Intranet do Exército:",
                    fontSize = 13.sp,
                    color = Color(0xFFFEF3C7),
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Caminho: Intranet > Serviços > multifator\n• Configuração: Inserir um e-mail válido e número de telefone móvel para receção das mensagens SMS de verificação.",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFFDE68A),
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Secção: Como Funciona a Aplicação
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Como Funciona a Aplicação",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                StepItem(
                    number = "1",
                    title = "Login nativo",
                    description = "O NIM e a password são pedidos num ecrã da app. Por trás, uma WebView escondida preenche e submete o portal verdadeiro em https://portal.rd.exercito.pt, que faz a cifra da password.",
                )

                StepItem(
                    number = "2",
                    title = "SMS User Consent API (Google Play Services)",
                    description = "A app aciona a API de consentimento do Google Play Services. Não é pedida nenhuma permissão de leitura de SMS (READ_SMS ou RECEIVE_SMS).",
                )

                StepItem(
                    number = "3",
                    title = "Autorização do Utilizador",
                    description = "Quando o SMS chega, o Android pede autorização para ler essa mensagem em concreto. Se a app estiver em segundo plano, aparece uma notificação.",
                )

                StepItem(
                    number = "4",
                    title = "Código preenchido e aplicações",
                    description = "O código de 6 dígitos é preenchido e submetido sozinho. Depois aparece a lista de aplicações do portal, que abrem dentro da app. O NIM e a password podem ser memorizados, cifrados, com a impressão digital.",
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Secção: Segurança & Privacidade
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color(0xFF4ADE80),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Segurança e Conformidade",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• Zero Permissões Intrusivas: A app não tem acesso ao histórico de mensagens nem à lista de contactos.\n• Comunicação Criptografada: Todo o tráfego com o Portal RD é realizado exclusivamente por HTTPS/TLS.\n• Credenciais Protegidas: o NIM e a password só são memorizados se o utilizador o pedir. Ficam cifrados e só se abrem com a impressão digital.",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (onSaveLog != null) {
            OutlinedButton(
                onClick = onSaveLog,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar registo de diagnóstico em Downloads", color = Color(0xFFCBD5E1))
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Botão de retorno
        Button(
            onClick = onNavigateBack,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B382B))
        ) {
            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Voltar", fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Rodapé
        Text(
            text = "Desenvolvido por SCh Cav Agostinho Fernandes 2026",
            fontSize = 11.sp,
            color = Color(0xFF64748B),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun StepItem(number: String, title: String, description: String) {
    Row(modifier = Modifier.padding(vertical = 6.dp)) {
        Surface(
            color = Color(0xFF1B382B),
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier.size(24.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = number, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC5A059))
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(text = description, fontSize = 12.sp, color = Color(0xFF94A3B8), lineHeight = 16.sp)
        }
    }
}
