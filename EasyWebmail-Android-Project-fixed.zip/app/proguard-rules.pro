# Regras ProGuard/R8 (adicionar aqui se necessário)
