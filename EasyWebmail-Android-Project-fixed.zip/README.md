# EasyWebmail — Portal Exército & SMS User Consent

**Aplicação Android Nativa em Kotlin e Jetpack Compose**  
*Desenvolvido por SCh Cav Agostinho Fernandes 2026*

---

## 🎯 Objetivo da Aplicação
O **EasyWebmail** foi desenvolvido especificamente para facilitar e acelerar o acesso seguro ao Portal RD do Exército Português (`https://portal.rd.exercito.pt/Login/Login`).  
Elimina a necessidade de o utilizador memorizar e digitar manualmente o código de verificação recebido por SMS, captando a mensagem de forma privada através da **SMS User Consent API da Google Play Services** e injetando o código OTP de 6 dígitos automaticamente no formulário web através de JavaScript.

---

## ⚠️ Requisito Prévio Obrigatório (Ativação de 2FA na Intranet)
Para que a autenticação de duplo fator funcione por SMS:
1. O utilizador deve aceder à **Intranet do Exército**.
2. Navegar para o menu: **Serviços > multifator**.
3. Inserir um **endereço de e-mail** e o **número de telefone móvel** onde pretende receber as mensagens com o código OTP.

Sem este passo prévio na Intranet, o sistema do Exército não enviará a mensagem SMS de segundo fator.

---

## 🛡️ Privacidade & Google SMS User Consent API
- **Sem Permissões Invasivas**: A aplicação **NÃO** solicita nem necessita de `READ_SMS` ou `RECEIVE_SMS` no manifesto.
- **Consentimento Explícito**: O sistema Google Play Services apresenta uma janela nativa oficial do sistema Android com o texto exato da mensagem recebida para autorização pontual do militar.
- **Apenas 1 Mensagem**: A permissão concedida aplica-se estritamente à SMS de verificação corrente.

---

## 🚀 Como Abrir e Compilar no Android Studio
1. Descarregue o ficheiro zip do projeto gerado pelo EasyWebmail Studio ou clone este repositório.
2. Abra o **Android Studio** (Koala, Ladybug ou versão mais recente).
3. Selecione **File > Open** e escolha a pasta raiz do projeto.
4. Aguarde a sincronização do Gradle (`Sync Project with Gradle Files`).
5. Conecte um dispositivo físico Android (ou crie um emulador com Google Play Services ativado).
6. Clique em **Run 'app'** (`Shift + F10`).

---

## 🧪 Como Testar a SMS User Consent API no Emulador
1. Abra o emulador Android Studio.
2. No painel lateral do emulador, clique nos **Três Pontos (...)** (Extended Controls).
3. Selecione o separador **Phone**.
4. No campo de SMS, insira uma mensagem com 6 dígitos, por exemplo:
   ```
   Exercito Portugues: O seu codigo de verificacao e 492018. Valido por 5 minutos.
   ```
5. Clique em **Send Message**.
6. A janela nativa de consentimento da Google surgirá imediatamente no ecrã.
7. Toque em **Permitir** / **Allow** e observe o código a ser extraído e injetado no campo de autenticação!

---

*Desenvolvido por SCh Cav Agostinho Fernandes 2026*
