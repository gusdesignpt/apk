package pt.exercito.rd.easywebmail.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

/**
 * Ecrã da WebView em Jetpack Compose.
 * 
 * Carrega https://portal.rd.exercito.pt/Login/Login com todas as configurações de segurança,
 * suporte para JavaScript e ponte de injeção automática para códigos OTP recebidos via SMS User Consent.
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    viewModel: WebViewModel,
    onRequestRestartSms: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val isLoading by viewModel.isLoading.collectAsState()
    val smsStatus by viewModel.smsStatus.collectAsState()
    val lastOtp by viewModel.lastReceivedOtp.collectAsState()
    var showIntranetBanner by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Alerta informativo: Requisito de ativação de Duplo Fator na Intranet
        AnimatedVisibility(visible = showIntranetBanner) {
            Surface(
                color = Color(0xFFFEF3C7), // Âmbar suave
                contentColor = Color(0xFF92400E),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Nota de Configuração",
                        tint = Color(0xFFB45309),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Atenção: É necessário ativar a autenticação por duplo fator na Intranet em Serviços > multifator e registar email e número de telefone.",
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = { showIntranetBanner = false },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Entendido", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                    }
                }
            }
        }

        // Barra de estado de escuta de SMS
        Surface(
            color = Color(0xFF1E293B),
            contentColor = Color(0xFFE2E8F0),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (lastOtp != null) Icons.Default.CheckCircle else Icons.Default.Sms,
                    contentDescription = null,
                    tint = if (lastOtp != null) Color(0xFF4ADE80) else Color(0xFFC5A059),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = smsStatus,
                    fontSize = 11.sp,
                    color = Color(0xFFCBD5E1),
                    modifier = Modifier.weight(1f)
                )
                if (lastOtp != null) {
                    Surface(
                        color = Color(0xFF166534),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(
                            text = "OTP: $lastOtp",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFFC5A059),
                trackColor = Color(0xFF1B382B)
            )
        }

        // Contentor da WebView Nativa
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    // Configurações essenciais para o Portal RD
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        setSupportZoom(true)
                        builtInZoomControls = true
                        displayZoomControls = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        cacheMode = WebSettings.LOAD_DEFAULT
                    }

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            viewModel.setLoading(true)
                            url?.let { viewModel.setCurrentUrl(it) }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            viewModel.setLoading(false)
                            url?.let { viewModel.setCurrentUrl(it) }

                            // Se já tivermos um OTP recebido antes de a página terminar de carregar, injeta
                            lastOtp?.let { otp ->
                                viewModel.injectOtpIntoWebView(otp)
                            }
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            // Mantém a navegação restrita dentro da WebView
                            return false
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            title?.let { viewModel.setPageTitle(it) }
                        }
                    }

                    viewModel.attachWebView(this)
                    loadUrl(WebViewModel.PORTAL_LOGIN_URL)
                }
            },
            update = { webView ->
                viewModel.attachWebView(webView)
            }
        )
    }
}
