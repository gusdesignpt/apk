package pt.exercito.rd.easywebmail

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status
import pt.exercito.rd.easywebmail.sms.SmsConsentBroadcastReceiver
import pt.exercito.rd.easywebmail.ui.EasyWebmailApp
import pt.exercito.rd.easywebmail.ui.theme.EasyWebmailTheme
import pt.exercito.rd.easywebmail.viewmodel.WebViewModel

/**
 * EasyWebmail - Portal Exército & SMS User Consent
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 * 
 * Esta Activity gere o ciclo de vida da aplicação, o início da escuta da SMS User Consent API,
 * a apresentação da folha de consentimento nativa da Google e a injeção do código OTP de 6 dígitos
 * na WebView via JavaScript.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "EasyWebmail"
        private const val SMS_CONSENT_REQUEST = 1002 // Código para onActivityResult clássico
    }

    private val viewModel: WebViewModel by viewModels()
    private var smsReceiver: SmsConsentBroadcastReceiver? = null

    // Launcher moderno do AndroidX Activity Result (substituto recomendado do onActivityResult)
    private val smsConsentLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            handleSmsConsentResult(result.resultCode, result.data)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa a escuta de SMS através do Google Play Services
        startSmsUserConsentListener()

        setContent {
            EasyWebmailTheme {
                EasyWebmailApp(
                    viewModel = viewModel,
                    onRequestRestartSmsListener = { startSmsUserConsentListener() }
                )
            }
        }
    }

    /**
     * Inicia o cliente SMS User Consent da Google Play Services.
     * senderPhoneNumber pode ser null para aceitar SMS de qualquer remetente que contenha
     * um código alfanumérico de 4 a 10 dígitos.
     */
    private fun startSmsUserConsentListener() {
        val client = SmsRetriever.getClient(this)
        // senderPhoneNumber = null permite captar o SMS do Exército/Operadora sem restringir o remetente
        client.startSmsUserConsent(null)
            .addOnSuccessListener {
                Log.d(TAG, "SMS User Consent API iniciada com sucesso.")
                viewModel.updateSmsStatus("A aguardar receção de SMS com código OTP...")
                registerSmsReceiver()
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Falha ao iniciar SMS User Consent API", e)
                viewModel.updateSmsStatus("Erro ao iniciar escuta de SMS: ${e.localizedMessage}")
            }
    }

    /**
     * Regista o BroadcastReceiver para captar a ação SMS_RETRIEVED da Google.
     */
    private fun registerSmsReceiver() {
        if (smsReceiver != null) return

        smsReceiver = SmsConsentBroadcastReceiver().apply {
            smsListener = object : SmsConsentBroadcastReceiver.SmsListener {
                override fun onConsentIntentReceived(consentIntent: Intent) {
                    try {
                        // Lança a janela de consentimento nativa da Google para o utilizador
                        Log.d(TAG, "Consent Intent recebido da Google. A abrir diálogo de autorização...")
                        smsConsentLauncher.launch(consentIntent)
                    } catch (e: ActivityNotFoundException) {
                        Log.e(TAG, "Erro ao abrir atividade de consentimento de SMS", e)
                    }
                }

                override fun onError(status: Status) {
                    Log.w(TAG, "SMS Receiver retornou estado de erro: ${status.statusMessage}")
                    if (status.statusCode == CommonStatusCodes.TIMEOUT) {
                        viewModel.updateSmsStatus("Tempo limite de escuta de SMS excedido.")
                    }
                }
            }
        }

        val intentFilter = IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(
                this,
                smsReceiver!!,
                intentFilter,
                ContextCompat.RECEIVER_EXPORTED
            )
        } else {
            registerReceiver(smsReceiver, intentFilter)
        }
    }

    /**
     * Tratamento moderno do resultado do consentimento da SMS.
     * Também compatível com o método clássico onActivityResult.
     */
    private fun handleSmsConsentResult(resultCode: Int, data: Intent?) {
        when (resultCode) {
            Activity.RESULT_OK -> {
                // Utilizador concedeu permissão para ler esta SMS específica
                val message = data?.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE)
                Log.d(TAG, "Mensagem SMS recebida com autorização do utilizador: $message")

                if (!message.isNullOrBlank()) {
                    val otp = extractOtpCode(message)
                    if (otp != null) {
                        Log.d(TAG, "Código OTP de 6 dígitos extraído com sucesso: $otp")
                        viewModel.onOtpReceived(otp)
                        Toast.makeText(
                            this,
                            "Código OTP ($otp) detetado! A injetar no Portal...",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Log.w(TAG, "Não foi possível extrair um código de 6 dígitos da SMS")
                        Toast.makeText(
                            this,
                            "SMS recebida, mas não foi encontrado código de 6 dígitos.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            Activity.RESULT_CANCELED -> {
                Log.i(TAG, "Utilizador recusou o consentimento para ler a SMS.")
                viewModel.updateSmsStatus("Consentimento de leitura de SMS cancelado pelo utilizador.")
            }
        }
    }

    /**
     * Suporte explícito ao fluxo clássico onActivityResult pedido nos requisitos.
     */
    @Deprecated("Deprecated in Java / Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SMS_CONSENT_REQUEST) {
            handleSmsConsentResult(resultCode, data)
        }
    }

    /**
     * Extrai um código numérico de 6 dígitos do corpo da mensagem SMS
     * usando uma expressão regular robusta.
     */
    private fun extractOtpCode(message: String): String? {
        val regex = Regex("\\b(\\d{6})\\b")
        return regex.find(message)?.value
    }

    override fun onDestroy() {
        super.onDestroy()
        smsReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao remover registo do receptor de SMS", e)
            }
            smsReceiver = null
        }
    }
}
