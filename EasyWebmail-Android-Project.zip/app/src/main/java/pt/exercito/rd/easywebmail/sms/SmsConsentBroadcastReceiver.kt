package pt.exercito.rd.easywebmail.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status

/**
 * Receptor de Broadcast para a SMS User Consent API do Google Play Services.
 * Não requer permissões READ_SMS ou RECEIVE_SMS no AndroidManifest!
 * 
 * Desenvolvido por SCh Cav Agostinho Fernandes 2026
 */
class SmsConsentBroadcastReceiver : BroadcastReceiver() {

    interface SmsListener {
        fun onConsentIntentReceived(consentIntent: Intent)
        fun onError(status: Status)
    }

    var smsListener: SmsListener? = null

    override fun onReceive(context: Context, intent: Intent) {
        if (SmsRetriever.SMS_RETRIEVED_ACTION == intent.action) {
            val extras = intent.extras ?: return

            @Suppress("DEPRECATION")
            val status: Status? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                extras.getParcelable(SmsRetriever.EXTRA_STATUS, Status::class.java)
            } else {
                extras.getParcelable(SmsRetriever.EXTRA_STATUS)
            }

            when (status?.statusCode) {
                CommonStatusCodes.SUCCESS -> {
                    // O Google Play Services intercetou a SMS e gerou um Intent de consentimento
                    @Suppress("DEPRECATION")
                    val consentIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT, Intent::class.java)
                    } else {
                        extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT)
                    }

                    if (consentIntent != null) {
                        smsListener?.onConsentIntentReceived(consentIntent)
                    } else {
                        Log.w("SmsConsentReceiver", "EXTRA_CONSENT_INTENT nulo")
                    }
                }
                CommonStatusCodes.TIMEOUT -> {
                    Log.w("SmsConsentReceiver", "SMS User Consent API atingiu o tempo limite (5 minutos)")
                    smsListener?.onError(status)
                }
                else -> {
                    if (status != null) {
                        smsListener?.onError(status)
                    }
                }
            }
        }
    }
}
